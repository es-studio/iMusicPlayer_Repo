//
//  FileInfo.h
//  iMusicPlayer
//
//  Created by Han Eunsung on 12. 1. 22..
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//
#import "FSItem.h"

#import <UIKit/UIKit.h>


@interface FileInfo : UITableViewController


@property (nonatomic, retain) FSItem *fsItem;
@property (nonatomic, retain) NSDictionary *infoDic;
@property (nonatomic, retain) NSArray *infoKeys;
@property (nonatomic, retain) NSDictionary *attribute;

- (id)initWithFilePath:(FSItem *)item;

- (void) dismissThis;

@end


