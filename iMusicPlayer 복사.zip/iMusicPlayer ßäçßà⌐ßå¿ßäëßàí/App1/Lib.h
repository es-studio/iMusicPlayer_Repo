//
//  Lib.h
//  iMusicPlayer
//
//  Created by Han Eunsung on 11. 10. 29..
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class LibraryDetailView;
@class MyMusicPlayer;


@interface Lib : UITableViewController {
    
    NSMutableDictionary     *DicPlayListDB;
    NSArray                 *PlayListKeysArray;
    NSMutableArray          *FilteredPlayList;
    
}

@property (nonatomic, retain) NSMutableDictionary *DicPlayListDB;
@property (nonatomic, retain) NSArray *PlayListKeysArray;
@property (nonatomic, retain) NSMutableArray *FilteredPlayList;
@property (nonatomic, retain) LibraryDetailView *DetailView;

//+ (Lib *) sharedLibrary;


- (void) alertMakePlaylist;

- (void) makeSQLPlaylists:(NSString *)name;

- (void) LoadPlaylist;

- (void) removePlayListArray:(NSString *)key;

- (void) removePlayListDictionary:(NSString *)key;

- (void)SavingFileInfo:(NSString *)key;

@end
