//
//  PlaylistTableCell.m
//  App1
//
//  Created by Han Eunsung on 11. 10. 12..
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "PlaylistTableCell.h"

@implementation PlaylistTableCell

@synthesize NumLabel;
@synthesize HereImage;
@synthesize BarImage;
@synthesize TitleLabel;
@synthesize TimeLabel;
@synthesize BarImage2;
@synthesize BarImage3;


- (void)dealloc {
    [NumLabel release];
    [HereImage release];
    [HereImage release];
    [BarImage release];
    [TitleLabel release];
    [TimeLabel release];
//    [super dealloc];
}
@end
