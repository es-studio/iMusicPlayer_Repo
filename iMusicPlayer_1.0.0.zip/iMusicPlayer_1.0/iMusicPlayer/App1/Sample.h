//
//  Sample.h
//  iMusicPlayer
//
//  Created by Han Eunsung on 11. 11. 24..
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Sample : UIViewController

@end
