//
//  Wifi.h
//  App1
//
//  Created by Eunsung Han on 11. 9. 14..
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class HTTPServer;


@interface Wifi : UIViewController {
    
    HTTPServer  *httpsvr;
    UILabel     *ipLabel;
    UISwitch    *onSwitch;
    
}

@property (retain, nonatomic) IBOutlet UILabel *ipLabel;
@property (retain, nonatomic) IBOutlet UISwitch *onSwitch;

- (void) initHTTPServer;

- (BOOL) checkWiFi;

-(NSString*)getAddress;

- (IBAction)toggleSwitch:(id)sender;

@end
