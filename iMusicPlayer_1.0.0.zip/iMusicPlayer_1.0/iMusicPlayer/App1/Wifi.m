//
//  Wifi.m
//  App1
//
//  Created by Eunsung Han on 11. 9. 14..
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#include <ifaddrs.h>
#include <arpa/inet.h>


#import "Wifi.h"

#import "HTTPServer.h"
#import "MyHTTPConnection.h"

#import "Reachability.h"

@implementation Wifi

@synthesize ipLabel;
@synthesize onSwitch;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)dealloc
{
    [ipLabel release];
    [onSwitch release];
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    NSLog(@"Wifi load");
    // non sleep
    [UIApplication sharedApplication].idleTimerDisabled = YES;
    [super viewDidLoad];
    
    self.navigationItem.title = @"Wi-Fi File Transfer";
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [self setIpLabel:nil];
    [self setOnSwitch:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewDidAppear:(BOOL)animated{
    
    if(httpsvr == nil) [self initHTTPServer];
    
    
//    [httpsvr start:nil];
    
//    NSLog(@"name =  %@", httpsvr.name);
//    NSLog(@"number of connections =  %d", httpsvr.numberOfHTTPConnections);    
//    NSLog(@"published name = %@",httpsvr.publishedName);
//    
    
    
//    [self getAddress];

}

- (void)viewDidDisappear:(BOOL)animated{
    [onSwitch setOn:FALSE animated:YES];
    ipLabel.text = @"Server is Not Running";
    [httpsvr stop];
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


- (void)initHTTPServer{
    
    NSString *root = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES) objectAtIndex:0];
    
    // http server 초기화 
	httpsvr = [HTTPServer new];
    
    // http server 기본 설정 
	[httpsvr setType:@"_http._tcp."];
	[httpsvr setConnectionClass:[MyHTTPConnection class]];
	[httpsvr setDocumentRoot:[NSURL fileURLWithPath:root]];
    [httpsvr setPort:8080];
    
    
}

- (NSString *)getAddress
{
    NSString *address = @"error";
    struct ifaddrs *interfaces = NULL;
    struct ifaddrs *temp_addr = NULL;
    int success = 0;
    
    // retrieve the current interfaces - returns 0 on success
    success = getifaddrs(&interfaces);
    if (success == 0)
    {
        // Loop through linked list of interfaces
        temp_addr = interfaces;
        while(temp_addr != NULL)
        {
            if(temp_addr->ifa_addr->sa_family == AF_INET)
            {
                // Check if interface is en0 which is the wifi connection on the iPhone
                if([[NSString stringWithUTF8String:temp_addr->ifa_name] isEqualToString:@"en0"])
                {
                    // Get NSString from C String
                    address = [NSString stringWithUTF8String:inet_ntoa(((struct sockaddr_in *)temp_addr->ifa_addr)->sin_addr)];
                }
            }
            
            temp_addr = temp_addr->ifa_next;
        }
    }
    
    // Free memory
    freeifaddrs(interfaces);
    
    return address;
}


- (IBAction)toggleSwitch:(id)sender {
    NSLog(@"toggle = %d", onSwitch.on);
    
    
    if([self checkWiFi] == FALSE){
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"HTTP Server Fail" message:@"Please turn on WiFi before start HTTP server" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        
        [alert show];
        [alert autorelease];
        
        onSwitch.on = FALSE;
        
        return;
        
    }
    

    if (onSwitch.on == TRUE) {
        NSLog(@"try on");
        ipLabel.text = [NSString stringWithFormat:@"http://%@:%d",  [self getAddress], httpsvr.port ];
//         httpserver 시작 
        NSError *error;
        if(![httpsvr start:&error])
        {
            NSLog(@"Error starting HTTP Server: %@", error);
        }

    }
    else {
        
        NSLog(@"try off!");
        ipLabel.text = @"Server is Not Running";

        [httpsvr stop];
    }

}

- (BOOL) checkWiFi{
    
    BOOL onWiFi;
    
    NetworkStatus netStatus = [[Reachability reachabilityForInternetConnection] currentReachabilityStatus];
    
    
    switch (netStatus) {
        case NotReachable:
            onWiFi = false;
            break;
            
        case ReachableViaWiFi:            
            onWiFi = TRUE;            
            break;
            
        default:
            onWiFi = FALSE;
            break;
    }
    
    return onWiFi;
    
}




@end
