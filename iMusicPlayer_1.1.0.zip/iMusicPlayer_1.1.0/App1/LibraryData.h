//
//  LibraryData.h
//  iMusicPlayer
//
//  Created by Han Eunsung on 12. 2. 17..
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LibraryData : NSObject

@property (nonatomic, retain) NSMutableDictionary *PlaylistDB;


+ (LibraryData *) sharedLibrary;

- (id)init;

- (void)LoadPlaylist;

- (void) makeSQLPlaylists:(NSString *)name;

- (void)removePlayListDictionary:(NSString *)key;

- (void)removePlayListArray:(NSString *)key;

- (void)SavingFileInfo:(NSString *)key;

@end
