//
//  MoreCtrlView.h
//  iMusicPlayer
//
//  Created by Han Eunsung on 12. 2. 12..
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MyMusicPlayer;

@interface MoreCtrlView : UIViewController{
    
    MyMusicPlayer   *mmusic;
    
}


//@property (nonatomic, retain) MyMusicPlayer  *music;


@property (nonatomic ,retain) IBOutlet UIButton *aButton;
@property (nonatomic ,retain) IBOutlet UIButton *bButton;

@property (nonatomic ,retain) IBOutlet UISlider *timeSlider;


@property (nonatomic, retain) IBOutlet UILabel  *xLabel;

@property (nonatomic, retain) IBOutlet UILabel  *leftTimeLabel;
@property (nonatomic, retain) IBOutlet UILabel  *rightTimeLabel;

@property (nonatomic, retain) UIStepper *xStepper;


@property (nonatomic ,retain) UIView *aLine;
@property (nonatomic ,retain) UIView *bLine;

@property (nonatomic) BOOL aToggled;
@property (nonatomic) BOOL bToggled;


- (void) initialize;

- (IBAction)reset:(id)sender;

- (IBAction)clickStep:(id)sender;

- (IBAction)toggleA:(id)sender;

- (IBAction)toggleB:(id)sender;

- (IBAction)timeSliderValueChange:(id)sender;


@end


