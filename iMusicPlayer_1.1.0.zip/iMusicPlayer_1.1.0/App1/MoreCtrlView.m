//
//  MoreCtrlView.m
//  iMusicPlayer
//
//  Created by Han Eunsung on 12. 2. 12..
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "MoreCtrlView.h"
#import "MyMusicPlayer.h"

@implementation MoreCtrlView

@synthesize aButton;
@synthesize bButton;
@synthesize xLabel;
@synthesize xStepper;
@synthesize aLine, bLine;
@synthesize aToggled, bToggled;
@synthesize leftTimeLabel, rightTimeLabel;
@synthesize timeSlider;

- (void)dealloc{
    
    [aButton release];
    [bButton release];
    [xLabel release];
    [xStepper release];
    
    [aLine release];
    [bLine release];
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    mmusic = [MyMusicPlayer sharedMusicPlayer];
    
    aLine = [[UIView alloc] init];
    bLine = [[UIView alloc] init];
    
    [aLine setBackgroundColor:[UIColor redColor]];
    [bLine setBackgroundColor:[UIColor redColor]];

}




- (void)initialize{ 
    
    self.aToggled = FALSE;
    self.bToggled = FALSE;
    
    float duration = mmusic.durationTimeSec;

    
    self.leftTimeLabel.text
    = [NSString stringWithString:@"00:00"];
    self.rightTimeLabel.text 
    = [NSString stringWithFormat:@"%02d:%02d", (int)duration / 60, (int)duration % 60, nil];
    [self.timeSlider setMaximumValue:mmusic.durationTimeSec * 1000000000];
    
    
//    self.bButton.enabled = FALSE;
    mmusic.onLoopMode = FALSE;
    mmusic.aTime = CMTimeMake(0, 1000 ^ 3);
    mmusic.bTime = CMTimeMake(0, 1000 ^ 3);
    
    [mmusic.player setRate:1.0];
    self.xLabel.text = @"x 1.0";
    

    [aLine removeFromSuperview];
    [bLine removeFromSuperview];
    
    
    [timeSlider setThumbImage:[UIImage imageNamed:@"Nobe"] forState:UIControlStateNormal];
//    [timeSlider setThumbImage:nil forState:UIControlStateNormal];
    [timeSlider setMaximumTrackImage:[UIImage imageNamed:@"MaxSlide"] forState:UIControlStateNormal];
    [timeSlider setMinimumTrackImage:[UIImage imageNamed:@"MinSlide"] forState:UIControlStateNormal];            

    
    
    NSLog(@"MoreCtrlView");

}


- (IBAction)timeSliderValueChange:(id)sender{
    
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    
    
    
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (IBAction)reset:(id)sender{
    [self initialize];
    
}

- (IBAction)clickStep:(id)sender{
    UIStepper *stepper = sender;
    
    [mmusic.player setRate:[stepper value]];
    self.xLabel.text = [NSString stringWithFormat:@"x %.1f", [stepper value]];
    
}

- (IBAction)toggleA:(id)sender{
    
    
    leftTimeLabel.text = mmusic.CurrentTime.text;
    mmusic.aTime = mmusic.player.currentTime;
    
    CGRect r = mmusic.Timeline.bounds;
    
    float current = mmusic.Timeline.value;
    float duration = mmusic.durationTimeSec;
    float position = (r.size.width - 20) * current / duration + 27;
    
    [aLine removeFromSuperview];
    aLine.frame = CGRectMake(position, 20, 1, 30);
    [mmusic.TopController insertSubview:aLine atIndex:2];
    
    
    self.leftTimeLabel.text 
    = [NSString stringWithFormat:@"%02d:%02d", (int)current / 60, (int)current % 60, nil];
    [self.timeSlider setMinimumValue:mmusic.player.currentTime.value];

//    self.bButton.enabled = TRUE;
    
}

- (IBAction)toggleB:(id)sender{
    
    rightTimeLabel.text = mmusic.CurrentTime.text;
    
    mmusic.bTime = mmusic.player.currentTime;
    
    CGRect r = mmusic.Timeline.bounds;
    float current = mmusic.Timeline.value;
    float duration = mmusic.durationTimeSec;
    float position = (r.size.width - 20) * current / duration + 27;
    
    [bLine removeFromSuperview];
    bLine.frame = CGRectMake(position, 20, 1, 30);
    [mmusic.TopController insertSubview:bLine atIndex:2];
    
    
    
    self.rightTimeLabel.text 
    = [NSString stringWithFormat:@"%02d:%02d", (int)current / 60, (int)current % 60, nil];
    [self.timeSlider setMaximumValue:mmusic.player.currentTime.value];
    


    mmusic.onLoopMode = TRUE;
    [mmusic.player seekToTime:mmusic.aTime];


    // + 3 sec
//    mmusic.bTime = CMTimeMake(mmusic.aTime.value * 3 + mmusic.aTime.timescale , mmusic.aTime.timescale);
    
    NSLog(@"B toggled");
    
    
//    CMTime currentTime = self.player.currentTime;    
//    currentTimeSec = currentTime.value / currentTime.timescale;
//    
//    if(self.player.rate > 0.0){
//        
//        CurrentTime.text 
//        = [NSString stringWithFormat:@"%02d:%02d", (int)currentTimeSec / 60, (int)currentTimeSec % 60, nil];


}


//int StartPoint;
//
//- (void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
//{
//	UITouch* touch = [touches anyObject];
//	CGPoint point = [touch locationInView:nil];
//    
//    
////    NSLog(@"start : x = %f, y = %f", point.x, point.y);
////    NSLog(@"view : x = %f, y = %f", self.view.center.x, self.view.center.y);
//    StartPoint = self.view.center.y - point.y;
//    
//
//	
//	
//}
//
//- (void) touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
//{
//	UITouch* touch = [touches anyObject];
//	CGPoint point = [touch locationInView:nil];
//    
////    NSLog(@"x = %f, y = %f", point.x, point.y);
//    
//    
//    
//    CGPoint p = self.view.center;
//    //    p.y = point.y + StartPoint.y;
//    p.y = point.y + StartPoint;
//    
//    if(p.y > 265 && p.y < 360){
//        
//        self.view.center = p;
//        
//    }
//    //	if (_uv.frame.origin.x < point.x && _uv.frame.origin.x + _uv.frame.size.width > point.x &&
//    //		_uv.frame.origin.y < point.y && _uv.frame.origin.y + _uv.frame.size.height > point.y)
//    //	{
//    //		//center  값을 재조종 한다
//    //		_uv.center = CGPointMake(point.x - _remainX, point.y - _remainY);
//    //	}
//}




@end
