//
//  FileTable.h
//  App1
//
//  Created by Han Eunsung on 11. 9. 17..
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Id3db.h"
#import "LoadingView.h"

#define kCellImageViewTag		1000

@class FSItem;
@class FSItemCell;

//@class Player;


@interface FileTable : UITableViewController 
                            <UIActionSheetDelegate, 
                            UIDocumentInteractionControllerDelegate, 
                            UIScrollViewDelegate>
{

    BOOL isEdit;
    FSItem *fsItem;  
    NSMutableArray *selectedArray;
    UIImage *selectedImage;
	UIImage *unselectedImage;	
    UIToolbar *actionToolbar;    
    
    UIDocumentInteractionController *docController;
    
    NSMutableArray *AlbumArtArray;

    NSOperationQueue *queue;
    
}


@property (nonatomic, retain) NSOperationQueue *queue;
@property (nonatomic, retain) NSMutableArray *AlbumArtArray;
@property BOOL isEdit;
@property (nonatomic, retain) FSItem *fsItem;
@property (nonatomic, retain) NSMutableArray *selectedArray;
@property (nonatomic, retain) UIImage *selectedImage;
@property (nonatomic, retain) UIImage *unselectedImage;
@property(nonatomic, retain) UIDocumentInteractionController *docController;
@property (nonatomic, retain) LoadingView *loading;
@property (nonatomic, retain) UIBarButtonItem *editButton;
@property (nonatomic, retain) UIBarButtonItem *playButton;


- (IBAction) toggleEdit:(id)sender;

- (void) showTabBar:(UITabBarController *) tabbarcontroller;

- (void) hideTabBar:(UITabBarController *) tabbarcontroller;

- (void) shiftCell:(FSItemCell *) cell;

- (void) showActionToolbar:(BOOL)show delay:(float)delay;

- (void) sortDirectoryFiles;

- (void) makeFile;

- (void) refreshFiles;

- (void) showMusicPlayer:(int)index;

- (void) alertMakeDir;

- (void) makeDir:(NSString *)dirName;

- (NSString *)URLEncoding:(NSString *)str;

- (int) checkMP3:(NSString *)name;

- (void) initBottomToolbar;

- (UIImage *) artworksForFileAtPath:(NSString *)filepath;

- (void) AlbumArtWorker:(FSItemCell *)cell;

- (void) refreshCells;

- (void) UpdateFileInfo;

- (NSString *)dataFilePath;

- (void) ShowUpdateFileInfo;

- (void) showPlayer;

- (BOOL) canBecomeFirstResponder;

- (void) remoteControlReceivedWithEvent:(UIEvent *)event;

- (void) deleteFileFromTableInDatabase:(NSArray *)pathArray;

- (void) showFileInfo:(NSNotification *)noti;

@end
