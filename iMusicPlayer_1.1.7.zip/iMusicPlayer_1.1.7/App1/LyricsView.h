//
//  LyricsView.h
//  iMusicPlayer
//
//  Created by Han Eunsung on 12. 2. 19..
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LyricsView : UIViewController

@property (nonatomic, retain) IBOutlet UITextView *lyricsText;

@end
