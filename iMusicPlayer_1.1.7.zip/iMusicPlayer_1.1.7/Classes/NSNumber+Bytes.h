#import <Foundation/Foundation.h>


@interface NSNumber (Bytes)

- (NSString *)prettyBytes;

@end
