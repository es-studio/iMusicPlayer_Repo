//
//  FileInfo.m
//  iMusicPlayer
//
//  Created by Han Eunsung on 12. 1. 22..
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "FileInfo.h"

@implementation FileInfo

@synthesize fsItem;
@synthesize infoDic;
@synthesize infoKeys;
@synthesize attribute;
@synthesize total_size;
@synthesize total;


- (void)dealloc{
    
    [fsItem release];
    [infoKeys release];
    [infoDic release];
    [attribute release];
    [super dealloc];
}


- (id)initWithFilePath:(FSItem *)item{

    fsItem = [item retain]; 
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];


    
    self.navigationItem.title = @"File Information";
    
    self.attribute = [NSDictionary dictionaryWithDictionary:self.fsItem.attributes];
    
    self.infoDic 
    = [[NSDictionary alloc] initWithObjectsAndKeys:
       [NSArray arrayWithObjects:
        @"Type",
        @"File", 
        @"FileSize",
        @"Creation Date",
        @"Modification Date", nil], 
       @"key 1",
//       [NSArray arrayWithObjects:
//        @"o11" , 
//        @"o22", nil], 
//       @"key 2",
       nil];
    
//    infoDic = fsItem.attributes;
    self.infoKeys = [self.infoDic allKeys];
    
    
    if ([self.attribute.fileType isEqualToString:@"NSFileTypeDirectory"]) {
        total_size = 0;
        NSFileManager *fm = [NSFileManager defaultManager];
        BOOL isDir;
        NSString *curDir = [NSString stringWithString:@""];
        NSDirectoryEnumerator* dirEnum = [fm enumeratorAtPath:fsItem.path];
        
        while ((curDir = [dirEnum nextObject]) != nil){
            
            
            if([fm fileExistsAtPath:curDir isDirectory:&isDir] == isDir)continue;
            
            NSString *newPath = [fsItem.path stringByAppendingPathComponent:curDir];
            NSDictionary *att = [fm attributesOfItemAtPath:newPath error:nil];
            
            NSNumber *numSize = [att objectForKey:NSFileSize];
            
            total_size += [numSize longLongValue];
            total++;
            
        }
    }else{
        total = 1;
        total_size = self.attribute.fileSize;
    }
    
}

- (void)dismissThis{
    
    [self dismissModalViewControllerAnimated:YES];
    
}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return [self.infoKeys count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    
    NSString *key = [self.infoKeys objectAtIndex:section];
    NSArray *array = [self.infoDic objectForKey:key];
    
    return [array count];
    
//    return [self.infoKeys count];
}


- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    
    if (section == 0) {
        return self.fsItem.filename;
    }
    
    return nil;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSUInteger section = [indexPath section];
    NSUInteger row = [indexPath row];
    
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:CellIdentifier] autorelease];
    }
    
    // Configure the cell...
    NSString *key = [self.infoKeys objectAtIndex:section];
    NSArray *arr = [self.infoDic objectForKey:key];
    NSString *str = [arr objectAtIndex:row];    
    
    
    cell.textLabel.font = [UIFont fontWithName:@"Helvetica-Bold" size:14];
    cell.detailTextLabel.font = [UIFont fontWithName:@"Helvetica-Bold" size:14];
    cell.textLabel.text = str;
    
    if(section == 0){
        
        switch (row) {
                
            case 0:                
                
                if ([self.attribute.fileType isEqualToString:@"NSFileTypeDirectory"]) {
                    cell.detailTextLabel.text = @"Directory";
                }else{
                    
                    cell.detailTextLabel.text = [self.fsItem.filename pathExtension];
                }
                break;
                
            case 1:
                
                cell.textLabel.text = @"Files";
                cell.detailTextLabel.text = [NSString stringWithFormat:@"%d", total];
                
                break;
            case 2:
            {
                
                // dir
                if ([self.attribute.fileType isEqualToString:@"NSFileTypeDirectory"]) {
                    
                    
                    NSString *size = [NSString stringWithFormat:@"%llu", total_size];
                    NSNumberFormatter *formatter = [[[NSNumberFormatter alloc] init] autorelease];
                    [formatter setNumberStyle:NSNumberFormatterDecimalStyle];
                    NSString *formatedSize = [formatter stringFromNumber:[formatter numberFromString:size]];
                    cell.detailTextLabel.text = [NSString stringWithFormat:@"%@ Byte", formatedSize];
                    cell.textLabel.text = @"TotalSize";
                    
                }
                // file
                else{
                    
                    NSString *size = [NSString stringWithFormat:@"%llu", total_size];
                    NSNumberFormatter *formatter = [[[NSNumberFormatter alloc] init] autorelease];
                    [formatter setNumberStyle:NSNumberFormatterDecimalStyle];
                    NSString *formatedSize = [formatter stringFromNumber:[formatter numberFromString:size]];
                    cell.detailTextLabel.text = [NSString stringWithFormat:@"%@ Byte", formatedSize];
                }

            }
                break;
                
            case 3:
                cell.detailTextLabel.text = [[self.attribute.fileCreationDate description] stringByReplacingOccurrencesOfString:@" +0000" withString:@""];
                break;
                
            case 4:

                cell.detailTextLabel.text = [[self.attribute.fileModificationDate description] stringByReplacingOccurrencesOfString:@" +0000" withString:@""];
                break;

            default:
                break;
        }
        
    }
    
    return cell;
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }   
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Navigation logic may go here. Create and push another view controller.
    /*
     <#DetailViewController#> *detailViewController = [[<#DetailViewController#> alloc] initWithNibName:@"<#Nib name#>" bundle:nil];
     // ...
     // Pass the selected object to the new view controller.
     [self.navigationController pushViewController:detailViewController animated:YES];
     [detailViewController release];
     */
}

@end
