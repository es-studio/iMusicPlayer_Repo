//
//  LyricsView.m
//  iMusicPlayer
//
//  Created by Han Eunsung on 12. 2. 19..
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "LyricsView.h"

@implementation LyricsView

@synthesize lyricsText;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(void)viewWillAppear:(BOOL)animated{

}
@end
