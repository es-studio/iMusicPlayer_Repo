//
//  Id3db.m
//  iMusicPlayer
//
//  Created by Han Eunsung on 11. 10. 27..
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "Id3db.h"

@implementation Id3db

@synthesize path, title, artist, album, AlbumArt, lyrics;
@synthesize duration;
@synthesize asset;

- (id)initWithURL:(NSURL *)url{
    asset = [[AVURLAsset alloc] initWithURL:url options:nil];

    self.title = [[url.path lastPathComponent] stringByDeletingPathExtension];
    self.artist = @"Unknown Artist";
    self.album = @"Unknown Album";
    self.lyrics = @"";
    
//    [self id3ForFileAtPath];
    return self;
}

- (NSString *)path{
    return [[asset URL] absoluteString];
}

- (void)id3ForFileAtPath{
    
    // id3 데이터 배열 얻기
    NSArray *formatArray = asset.availableMetadataFormats;

    if([formatArray count] == 0) return;
    
    // 플레이타임 가져오기
    duration = asset.duration.value / asset.duration.timescale;

    // 가사가 있을 경우
    if([[asset lyrics] length] > 0) lyrics = [asset lyrics];
    
    // id3 배열 얻기
    NSArray *array = [asset metadataForFormat:[formatArray objectAtIndex:0]]; //for get id3 tags
    
    for(AVMetadataItem *metadata in array) { 
//        if ([metadata.commonKey isEqualToString:@"artwork"]){
//            // 앨범아트 추출 못하는 경우가 많아 다른 메소드로 대체 
//        }
        if([metadata.commonKey isEqualToString:@"title"]){
            if (metadata.stringValue == @"") continue; // 비어있는 문자는 패스 
            self.title = metadata.stringValue;
//            NSLog(@"get title = %@", title);
        }
        else if([metadata.commonKey isEqualToString:@"artist"]){
            if (metadata.stringValue == @"") continue; // 비어있는 문자는 패스 
            self.artist = metadata.stringValue;
//            NSLog(@"get artist = %@", artist);
        }
        else if([metadata.commonKey isEqualToString:@"albumName"]){
            if (metadata.stringValue == @"") continue; // 비어있는 문자는 패스 
            self.album = metadata.stringValue;
//            NSLog(@"get album = %@", album);
        }
    }
    
}



- (void)dealloc
{
    duration = 0;
    [path release];
    [title release];
    [artist release];
    [album release];
    [AlbumArt release];
    
    [super dealloc];
}





@end
