//
//  Lib.m
//  iMusicPlayer
//
//  Created by Han Eunsung on 11. 10. 29..
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "Lib.h"
#import "LibraryDetailView.h"
#import "MyMusicPlayer.h"

#import "Id3db.h"

#import <sqlite3.h>



@implementation Lib

@synthesize PlayListKeysArray;
@synthesize FilteredPlayList;
@synthesize DetailView;
@synthesize DicPlayListDB;

//static Lib *sharedLibrary;
//
//+ (Lib *)sharedLibrary{
//    
//    // init Singletone
//    if (sharedLibrary == nil) {
//        
//        sharedLibrary = [[Lib alloc] init];
//        NSLog(@"Library Singleton Created");
//    }else{
//        NSLog(@"LIbrary Singleton already Created");
//    }
//    return sharedLibrary;
//
//}


#pragma mark - Remote control

- (BOOL) canBecomeFirstResponder{
    //    return firstResponder;
    return YES;
}


- (void) remoteControlReceivedWithEvent:(UIEvent *)event{
    
    
    NSLog(@"event = %d", event.subtype);
    
    MyMusicPlayer *mplayer = [MyMusicPlayer sharedMusicPlayer];
    
    if([mplayer.playlist count] > 0){
        
        if(event.subtype == UIEventSubtypeRemoteControlTogglePlayPause){
            [mplayer Play:event];
            //        [self Play:event];
        }else if(event.subtype == UIEventSubtypeRemoteControlNextTrack){
            
            [mplayer Next:event];
            //        [self Next:event];
        }else if(event.subtype == UIEventSubtypeRemoteControlPreviousTrack){
            [mplayer Prev:event];
            //        [self Prev:event];
        }
        
    }
}



- (id)initWithStyle:(UITableViewStyle)style{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)LoadPlaylist{
    
    NSMutableArray *tableArray = [NSMutableArray array];
    
    
    NSLog(@"LoadingFileInfo");
    
    // Set File Manager
    NSArray *docs = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docPath = [docs objectAtIndex:0];
    NSString *playlistFile = [docPath stringByAppendingPathComponent:@"/tmp/playlists.sqlite3"];

    //--------------------------------------------------------------------
    // 초기 애플리케이션 오픈시 데이터 베이스 파일 읽어 들이기 
    // sql 열기
    sqlite3 *database;
    if (sqlite3_open([playlistFile UTF8String], &database)
		!= SQLITE_OK) {
        sqlite3_close(database);
        NSAssert(0, @"Failed to open database");
    }
    
    
    // make sql string
    NSString *query = [NSString stringWithString:@"SELECT name FROM sqlite_master WHERE type='table';"];
    
    // Run SQL Query
    sqlite3_stmt *statement;
    if (sqlite3_prepare_v2(database, [query UTF8String], -1, &statement, nil) == SQLITE_OK) {
        
        while (sqlite3_step(statement) == SQLITE_ROW) {
            
            char *tables = (char *)sqlite3_column_text(statement, 0);
            [tableArray addObject:[NSString stringWithCString:tables encoding:NSUTF8StringEncoding]];
            [DicPlayListDB setObject:[[NSMutableArray alloc] init] forKey:[NSString stringWithCString:tables encoding:NSUTF8StringEncoding]];
            
        }
        sqlite3_finalize(statement);
    }
    
    NSLog(@"PlayLists = %@", tableArray);
    
    for (NSString *PlaylistName in tableArray) {
        
        NSMutableArray *listArray = [DicPlayListDB objectForKey:PlaylistName];
        NSString *query = [NSString stringWithFormat:@"SELECT FILEPATH, PATH, FILENAME, TITLE, ARTIST, ALBUM, LYRICS, DURATION FROM \"%@\"", PlaylistName];
        
        // Run SQL Query
        sqlite3_stmt *statement;
        if (sqlite3_prepare_v2(database, [query UTF8String], -1, &statement, nil) == SQLITE_OK) {
            
            while (sqlite3_step(statement) == SQLITE_ROW) {
                
                char *filepath  = (char *)sqlite3_column_text(statement, 0);
//                char *path      = (char *)sqlite3_column_text(statement, 1);
//                char *filename  = (char *)sqlite3_column_text(statement, 2);
                char *title     = (char *)sqlite3_column_text(statement, 3);
                char *artist    = (char *)sqlite3_column_text(statement, 4);
                char *album     = (char *)sqlite3_column_text(statement, 5);
                char *lyrics    = (char *)sqlite3_column_text(statement, 6);
                char *duration  = (char *)sqlite3_column_text(statement, 7);
                                
                // replace string ex) '%03F' -> '?'
                NSString *fpath = [[NSString stringWithCString:filepath encoding:NSUTF8StringEncoding] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];

                
                NSURL *fileurl;
                if([fpath rangeOfString:@"ipod-library"].location == NSNotFound){
                
                    fileurl = [NSURL fileURLWithPath:[docPath stringByAppendingPathComponent:fpath]];
                    
//                    NSLog(@"path = %@ | %@", docPath, fpath);
                    
                }else{
                    fileurl = [NSURL URLWithString:fpath];
                }

                Id3db *item = [[Id3db alloc] initWithURL:fileurl];
                item.title  = [NSString stringWithCString:title encoding:NSUTF8StringEncoding];
                item.artist = [NSString stringWithCString:artist encoding:NSUTF8StringEncoding];
                item.album  = [NSString stringWithCString:album encoding:NSUTF8StringEncoding];
                item.lyrics = [NSString stringWithCString:lyrics encoding:NSUTF8StringEncoding];
                item.duration  = [[NSString stringWithCString:duration encoding:NSUTF8StringEncoding] floatValue];
                
                
                NSLog(@"Open Path : %@", [NSString stringWithCString:filepath encoding:NSUTF8StringEncoding]);
                
                [listArray addObject:item];
                
            }
            sqlite3_finalize(statement);
        }
        
    }
    
    sqlite3_close(database);
    


    PlayListKeysArray = [[NSArray alloc] initWithObjects:@"Add Playlist...", nil];
    NSMutableArray *mPlayListKeysArray = [PlayListKeysArray mutableCopy];
    [mPlayListKeysArray addObjectsFromArray:[DicPlayListDB allKeys]];    
    PlayListKeysArray = mPlayListKeysArray;

    
}

- (void)viewDidLoad{
    [super viewDidLoad];
    
    NSLog(@"lib load");

    DicPlayListDB = [[NSMutableDictionary alloc] init];
    
    [self LoadPlaylist];

    
    
    
}

- (void)viewDidUnload{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    // player check
    MyMusicPlayer *mmplayer = [MyMusicPlayer sharedMusicPlayer];
    if (mmplayer.player.rate > 0.0) {
        
        
        UIImage *normal = [UIImage imageNamed:@"nowplaying_normal.png"];
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.bounds = CGRectMake( 0, 0, normal.size.width / 2, normal.size.height / 2);    
        [button setImage:normal forState:UIControlStateNormal];
        [button addTarget:self action:@selector(showMusic) forControlEvents:UIControlEventTouchUpInside];    
        UIBarButtonItem *MusicButton = [[UIBarButtonItem alloc] initWithCustomView:button];
        
        self.navigationItem.rightBarButtonItem = MusicButton;
        [MusicButton release];
    }else{
        self.navigationItem.rightBarButtonItem = nil;
    }
    
    
    
    //[self LoadPlaylist];


}

- (void)showMusic{
    MyMusicPlayer *imp = [MyMusicPlayer sharedMusicPlayer];
    imp.hidesBottomBarWhenPushed = TRUE;
    [self.navigationController pushViewController:imp animated:YES];
    
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    [self.tableView reloadData];
    
    
    // remote control regist
    [[UIApplication sharedApplication] beginReceivingRemoteControlEvents];
    [self canBecomeFirstResponder];

}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    NSLog(@"count = %d",[PlayListKeysArray count]);
    // Return the number of rows in the section.
    return [PlayListKeysArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    static NSString *CellIdentifier = @"Cell";
    
    int row = indexPath.row;
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
    }
    
    if(row != 0) cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    else cell.accessoryType = UITableViewCellAccessoryNone;

//    NSLog(@"cell = %@", [ArrayPlayList objectAtIndex:row]);
    cell.textLabel.text = [PlayListKeysArray objectAtIndex:row];
    
    return cell;
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    

    
    int row = indexPath.row;
    if(row == 0 ){
        [self alertMakePlaylist];
        
    }else{
        
        // Row Selection name
        NSString *key = [PlayListKeysArray objectAtIndex:row];
        
        NSLog(@"Selection = %@ cnt = %d", key, [[DicPlayListDB objectForKey:key] count]);
        
        self.DetailView = nil;
        NSLog(@"Selection = %@ cnt = %d", key, [[DicPlayListDB objectForKey:key] count]); 
       

        self.DetailView 
        = [[LibraryDetailView alloc] initWithKey:key array:[DicPlayListDB objectForKey:key]];
        
//        self.DetailView.PlaylistKey = key;
//        self.DetailView.PlaylistArray = [DicPlayListDB objectForKey:key];
           
        self.DetailView.lib = self;
        [self.navigationController pushViewController:self.DetailView animated:YES];
        [self.DetailView release];
        
        NSLog(@"detailvoew load ");
    }
    
    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];


}

- (void) alertMakePlaylist{
    
    UIAlertView *myAlertView = [[UIAlertView alloc] initWithTitle:@"New Playlist" message:@"\n\n" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"OK", nil];

    
    UITextField *myTextField = [[UITextField alloc] initWithFrame:CGRectMake(12.0, 55.0, 260.0, 30.0)];
    [myTextField setBackgroundColor:[UIColor whiteColor]];
    [myAlertView addSubview:myTextField];
    
    myTextField.borderStyle = UITextBorderStyleBezel;
    myTextField.autocapitalizationType = UITextAutocapitalizationTypeNone;
    myTextField.autocorrectionType = UITextAutocorrectionTypeNo;
    myTextField.font = [UIFont systemFontOfSize:18];
    [myTextField becomeFirstResponder];
    
    
    myAlertView.tag = 1000;
    [myAlertView show];
    [myAlertView release];
    [myTextField release];
    
    // set focus
    
    
}

- (void) alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    
    if(alertView.tag == 1000 && buttonIndex == 1){
        
        // array 에 추가 
        UITextField *TextField = [alertView.subviews objectAtIndex:5];
        if([TextField.text length] == 0) return;
        NSLog(@"condition passed");
        NSMutableArray *tmpArray = [PlayListKeysArray mutableCopy];
        [tmpArray addObject:TextField.text];        
        PlayListKeysArray = tmpArray;
        
        // dic 에 추가 
        [DicPlayListDB setObject:[[NSArray alloc] init] forKey:TextField.text];
        
        [self.tableView reloadData];
        [TextField release];
        
        //SQL make
        [self makeSQLPlaylists:TextField.text];

    }
    
}


- (void) makeSQLPlaylists:(NSString *)name{
    
    NSLog(@"make SQL Playlists");
    
    // Set File Manager
    NSArray *docs = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docPath = [docs objectAtIndex:0];

    //--------------------------------------------------------------------
    // 초기 애플리케이션 오픈시 데이터 베이스 파일 읽어 들이기 
    // sql 열기
    sqlite3 *database;
    if (sqlite3_open([[docPath stringByAppendingPathComponent:@"/tmp/playlists.sqlite3"] UTF8String], &database)
		!= SQLITE_OK) {
        sqlite3_close(database);
        NSAssert(0, @"Failed to open database");
    }
	
    // 테이블 생성 없을 경우 새로 만듬
    char *errorMsg;
    NSString *createSQL 
    = [NSString stringWithFormat:@"CREATE TABLE IF NOT EXISTS \"%@\" (FILEPATH TEXT PRIMARY KEY, PATH TEXT, FILENAME TEXT, TITLE TEXT, ARTIST TEXT, ALBUM TEXT, LYRICS TEXT, DURATION TEXT);", name];
    
    // SQL 실행
    if (sqlite3_exec (database, [createSQL UTF8String], NULL, NULL, &errorMsg) != SQLITE_OK) {
        sqlite3_close(database);
        NSAssert1(0, @"Error creating table: %s", errorMsg);
    }else{
        NSLog(@"%@ Table created", name);
    }

      
    
}




- (void)removePlayListArray:(NSString *)key{
    
    [DicPlayListDB setObject:[[NSArray alloc] init] forKey:key];

    // Set File Manager
    NSArray *docs = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docPath = [docs objectAtIndex:0];    
    NSString *playlistFile = [docPath stringByAppendingPathComponent:@"/tmp/playlists.sqlite3"];
    
    //--------------------------------------------------------------------
    // 초기 애플리케이션 오픈시 데이터 베이스 파일 읽어 들이기 
    // sql 열기
    sqlite3 *database;
    if (sqlite3_open([playlistFile UTF8String], &database)
		!= SQLITE_OK) {
        sqlite3_close(database);
        NSAssert(0, @"Failed to open database");
    }
    
        
    NSString *query = [NSString stringWithFormat:@"DELETE FROM \"%@\" WHERE DURATION >= 0", key];
    
    
    NSLog(@"Query = %@", query);
    
    sqlite3_stmt *stmt;
    if (sqlite3_prepare_v2(database, [query UTF8String], -1, &stmt, nil) != SQLITE_OK) {
        NSAssert1(0, @"Error while creating delete statement. '%s'", sqlite3_errmsg(database));
    }
    
    if (sqlite3_step(stmt) != SQLITE_DONE){
        NSLog(@"Delete Error");
    }else{
        NSLog(@"Delete Success");
    }
    sqlite3_finalize(stmt);
    sqlite3_close(database);

}

- (void)removePlayListDictionary:(NSString *)key{
    
    
    // 원본 db 에서 삭제         
    [DicPlayListDB removeObjectForKey:key];
    
    NSMutableArray *marray = [PlayListKeysArray mutableCopy];
    [marray removeObject:key];
    PlayListKeysArray = marray;
    
    
    
    // Set File Manager
    NSArray *docs = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docPath = [docs objectAtIndex:0];    
    NSString *playlistFile = [docPath stringByAppendingPathComponent:@"/tmp/playlists.sqlite3"];
    
    //--------------------------------------------------------------------
    // 초기 애플리케이션 오픈시 데이터 베이스 파일 읽어 들이기 
    // sql 열기
    sqlite3 *database;
    if (sqlite3_open([playlistFile UTF8String], &database)
		!= SQLITE_OK) {
        sqlite3_close(database);
        NSAssert(0, @"Failed to open database");
    }
    
    
    NSString *query = [NSString stringWithFormat:@"DROP TABLE \"%@\"", key];
    
    
    NSLog(@"Query = %@", query);
    
    sqlite3_stmt *stmt;
    if (sqlite3_prepare_v2(database, [query UTF8String], -1, &stmt, nil) != SQLITE_OK) {
        NSAssert1(0, @"Error while creating delete statement. '%s'", sqlite3_errmsg(database));
    }
    
    if (sqlite3_step(stmt) != SQLITE_DONE){
        NSLog(@"Delete Table Error");
    }else{
        NSLog(@"Delete Table Success");
    }
    sqlite3_finalize(stmt);
    sqlite3_close(database);

    
    
    

}


- (void)SavingFileInfo:(NSString *)key{
    
    NSLog(@"SavingFileInfo");
    
    // Set File Manager
    NSArray *docs = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docPath = [docs objectAtIndex:0];
    NSString *ndocPath = [NSString stringWithFormat:@"file://localhost%@/", docPath];
    
    
    NSString *playlistFile = [docPath stringByAppendingPathComponent:@"/tmp/playlists.sqlite3"];
    
    
    //--------------------------------------------------------------------
    // 초기 애플리케이션 오픈시 데이터 베이스 파일 읽어 들이기 
    // sql 열기
    sqlite3 *database;
    if (sqlite3_open([playlistFile UTF8String], &database)
		!= SQLITE_OK) {
        sqlite3_close(database);
        NSAssert(0, @"Failed to open database");
    }
    
    
    NSArray *playlistArray = [self.DicPlayListDB objectForKey:key];
    
    for (Id3db *id3 in playlistArray) {
        
        // 경로표현의 앞 프리픽스 삭제
        //NSString *file = [id3.path stringByReplacingOccurrencesOfString:ndocPath withString:@""];
        NSString *file 
        = [[id3.path stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding] 
           stringByReplacingOccurrencesOfString:ndocPath withString:@""]; 

        
        
        NSString *query = [NSString stringWithFormat:@"INSERT OR REPLACE INTO \"%@\" (FILEPATH, PATH, FILENAME, TITLE, ARTIST, ALBUM, LYRICS, DURATION) VALUES (?, ?, ?, ?, ?, ?, ?, ?);", key];
        
//        NSLog(@"title = %@ %@", id3.title, [[id3.asset URL] absoluteString]);
        
        sqlite3_stmt *stmt;
        if (sqlite3_prepare_v2(database, [query UTF8String], -1, &stmt, nil) == SQLITE_OK) {
            
            // "/abc/def.mp3"
            sqlite3_bind_text(stmt, 1, [file UTF8String], -1, NULL);
            
            // "/abc"
            sqlite3_bind_text(stmt, 2, [[file stringByDeletingLastPathComponent] UTF8String], -1, NULL);
            
            // "def.mp3"
            sqlite3_bind_text(stmt, 3, [[file lastPathComponent] UTF8String], -1, NULL);
            
            sqlite3_bind_text(stmt, 4, [id3.title UTF8String], -1, NULL);          
            sqlite3_bind_text(stmt, 5, [id3.artist UTF8String], -1, NULL);          
            sqlite3_bind_text(stmt, 6, [id3.album UTF8String], -1, NULL);          
            sqlite3_bind_text(stmt, 7, [id3.lyrics UTF8String], -1, NULL);          
            sqlite3_bind_text(stmt, 8, [[NSString stringWithFormat:@"%f", id3.duration] UTF8String], -1, NULL);                      
            
            NSLog(@"Save Path : %@", file);
            
        }
        
        if (sqlite3_step(stmt) != SQLITE_DONE){
            NSLog(@"Save Error");
            //            NSAssert1(0, @"Error updating table: %s", errorMsg);
        }else{
            NSLog(@"Save OK");
        }
        sqlite3_finalize(stmt);
        
    }
    sqlite3_close(database);
}



@end

