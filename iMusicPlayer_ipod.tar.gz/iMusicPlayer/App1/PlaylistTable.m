//
//  PlaylistTable.m
//  App1
//
//  Created by Han Eunsung on 11. 10. 11..
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "PlaylistTable.h"
#import "PlaylistTableCell.h"
#import <QuartzCore/QuartzCore.h>

#import "MyMusicPlayer.h"
#import "Id3db.h"


@implementation PlaylistTable

@synthesize mplayer;
@synthesize here;


- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor clearColor];
    self.tableView.separatorColor = [UIColor darkGrayColor];
    
//    
//    AVURLAsset *asset = [[AVURLAsset alloc] initWithURL:[NSURL fileURLWithPath:item] options:nil];
//    
//    int duration = asset.duration.value / asset.duration.timescale;
//    
//    cell.TimeLabel.text = [NSString stringWithFormat:@"%02d:%02d", duration / 60, duration % 60];
//    
//    duration = 0;
//    [asset release];

}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
    
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{

    // Return the number of rows in the section.
    return [mplayer.playlist count];

}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"PlaylistCell";
    int row = [indexPath row];    
    
//    PlaylistTableCell *cell = (PlaylistTableCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    PlaylistTableCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];

    if (cell == nil) {
         cell = (PlaylistTableCell *)[[[NSBundle mainBundle] loadNibNamed:@"PlaylistTableCell" owner:self options:nil] lastObject];

    }    
    


    if(cell.backgroundView == nil) cell.backgroundView = [[[UIView alloc] init] autorelease];
    
    
    if(row % 2 == 0){
        cell.backgroundView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.5];
//        cell.backgroundView.alpha = 0.1;
    }else {
        cell.backgroundView.backgroundColor = [UIColor clearColor];   
    }

    cell.backgroundView.alpha = 0.3;
    
    if(row == mplayer.index) cell.HereImage.hidden = FALSE;    
    
    
    CGColorRef cc = [UIColor colorWithRed:0.3 green:0.3 blue:0.3 alpha:1].CGColor;
    
    cell.BarImage.layer.borderColor       = cc;
    cell.BarImage2.layer.borderColor      = cc;
    cell.BarImage3.layer.borderColor      = cc;
    cell.backgroundView.layer.borderColor = cc;
    
    cell.BarImage.layer.borderWidth       = 1;
    cell.BarImage2.layer.borderWidth      = 1;
    cell.BarImage3.layer.borderWidth      = 1;
    cell.backgroundView.layer.borderWidth = 0;
    
    Id3db *id3item = [mplayer.playlist objectAtIndex:row];
    

    cell.TitleLabel.text = id3item.title;
    cell.TimeLabel.text = [NSString stringWithFormat:@"%02d:%02d", (int)id3item.duration / 60, (int)id3item.duration % 60];
    cell.NumLabel.text = [NSString stringWithFormat:@"%d.", row+1];
    return cell;
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{    
    [mplayer PlayAtIndex:[indexPath row]];
    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
        
}





@end
