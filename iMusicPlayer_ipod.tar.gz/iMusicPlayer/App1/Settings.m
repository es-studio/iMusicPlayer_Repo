//
//  Settings.m
//  iMusicPlayer
//
//  Created by Han Eunsung on 11. 12. 31..
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "Settings.h"
#import "SettingsData.h"
#import "Id3db.h"
#import "LoadingView.h"
#import "MyMusicPlayer.h"

#import "ActionSheetStringPicker.h"

#import <sqlite3.h>

@implementation Settings

@synthesize SettingsArray;
@synthesize SettingsKeys;
@synthesize Settings;
@synthesize loading;
@synthesize FontSizeArray;
@synthesize actionSheetPicker;


#pragma mark - Remote control

- (BOOL) canBecomeFirstResponder{
    //    return firstResponder;
    return YES;
}


- (void) remoteControlReceivedWithEvent:(UIEvent *)event{
    
    
    NSLog(@"event = %d", event.subtype);
    
    MyMusicPlayer *mplayer = [MyMusicPlayer sharedMusicPlayer];
    
    if([mplayer.playlist count] > 0){
        
        if(event.subtype == UIEventSubtypeRemoteControlTogglePlayPause){
            [mplayer Play:event];
            //        [self Play:event];
        }else if(event.subtype == UIEventSubtypeRemoteControlNextTrack){
            
            [mplayer Next:event];
            //        [self Next:event];
        }else if(event.subtype == UIEventSubtypeRemoteControlPreviousTrack){
            [mplayer Prev:event];
            //        [self Prev:event];
        }
        
    }
}


- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];

//    self.SettingsArray 
//    = [[NSDictionary alloc] initWithObjectsAndKeys:       
//       [[NSArray alloc] initWithObjects:@"Enable AlbumArt", @"Lockscreen PlayInfo", @"Files Font Size", nil], @"Settings",
//       [[NSArray alloc] initWithObjects:@"Clear AlbumArt Cache", @"Clear ID3 Database", @"Clear Playlist Database", nil], @"Clear Data",
//       nil];
    
    self.SettingsArray 
    = [[NSDictionary alloc] initWithObjectsAndKeys:       
       [NSArray arrayWithObjects:@"Enable AlbumArt", @"Lockscreen PlayInfo", @"Files Font Size", nil], @"Settings",
       [NSArray arrayWithObjects:@"Clear AlbumArt Cache", @"Clear ID3 Database", @"Clear Playlist Database", nil], @"Clear Data",
       nil];

    
    self.SettingsKeys = [self.SettingsArray allKeys];
    self.Settings     = [SettingsData sharedSettingsData];
    
    self.FontSizeArray = [[NSArray alloc] initWithObjects: @"10", @"12",@"14", @"16", @"18", @"20", @"22", nil];
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    
    // remote control regist
    [[UIApplication sharedApplication] beginReceivingRemoteControlEvents];
    [self canBecomeFirstResponder];

}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
//    [[UIApplication sharedApplication] endReceivingRemoteControlEvents];
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    
    // save configuration Data
    [self.Settings saveData];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return [self.SettingsKeys count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    NSString *key = [self.SettingsKeys objectAtIndex:section];
    NSArray *SectionArray = [self.SettingsArray objectForKey:key];
    return [SectionArray count];
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSUInteger section = [indexPath section];
    NSUInteger row = [indexPath row];
    
    NSString *key = [self.SettingsKeys objectAtIndex:section];
    NSArray *SectionArray = [self.SettingsArray objectForKey:key];

    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:CellIdentifier] autorelease];
    }
    
    // Configure the cell...
    cell.textLabel.text = [SectionArray objectAtIndex:row];
    
    cell.textLabel.font = [UIFont fontWithName:@"Helvetica-Bold" size:17];
    
    
    if(section == 0){
        
        switch (row) {
            case 0:
            {
                UISwitch *mySwitch = [[[UISwitch alloc] initWithFrame:CGRectZero] autorelease];
                [cell addSubview:mySwitch];
                cell.accessoryView = mySwitch;
                cell.selectionStyle = UITableViewCellSelectionStyleNone;                
                [mySwitch addTarget:self action:@selector(switchToggled:) forControlEvents:UIControlEventValueChanged];
                mySwitch.tag = 1000;
                mySwitch.on = self.Settings.OnAlbumArt;
            }   
                break;
                
            case 1:
            {
                UISwitch *mySwitch = [[[UISwitch alloc] initWithFrame:CGRectZero] autorelease];
                [cell addSubview:mySwitch];
                cell.accessoryView = mySwitch;
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                [mySwitch addTarget:self action:@selector(switchToggled:) forControlEvents:UIControlEventValueChanged];
                mySwitch.tag = 1001;
                mySwitch.on = self.Settings.OnLockScreenInfo;
            }   
                break;
                
            case 2:
                
                cell.detailTextLabel.text = [NSString stringWithFormat:@"%d pt", self.Settings.FileTableFontSize];
                
                break;
                
            default:
                break;
        }
        

        
    }
    
    return cell;
}


- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    NSString *key = [self.SettingsKeys objectAtIndex:section];
    return key;
}


- (void) switchToggled:(id)sender {
    //a switch was toggled.  
    //maybe use it's tag property to figure out which one
    UISwitch *sw = (UISwitch *)sender;
    
    switch (sw.tag) {
        case 1000:
            
            if(sw.isOn == TRUE) {
                self.Settings.OnAlbumArt = TRUE;
            }else{  
                self.Settings.OnAlbumArt = FALSE;
            }
            break;
            
        case 1001:         
            {            
                MyMusicPlayer *mplayer = [MyMusicPlayer sharedMusicPlayer];
                               
                if(sw.isOn == TRUE) {
                    self.Settings.OnLockScreenInfo = TRUE;
                    [mplayer onLockInfo];
                    
                }else{  
                    self.Settings.OnLockScreenInfo = FALSE;
                    [mplayer offLockInfo];
                }
                
            }
            break;
            
        default:
            break;
    }
    
    
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    
    
    if(indexPath.section == 1){
        
        switch (indexPath.row) {
            case 0:
                [self alertClearAlbumArt];
                break;
            case 1:
                [self alertClearID3Database];
                break;
            case 2:
                [self alertClearPlaylistDatabase];
                break;
            default:
                break;
        }
        
    }else if(indexPath.section == 0){
    
        switch (indexPath.row) {
            case  2:
            {
//                UIPickerView *pick = [[UIPickerView alloc] initWithFrame:CGRectMake(0, 240, 320, 415)];
//                
//                pick.showsSelectionIndicator = YES;
//                pick.dataSource = self;
//                pick.delegate = self;
//                
//                [self.tabBarController.view addSubview:pick];
//                
//                
//                [pick release];
//                
                
//                ActionStringDoneBlock done = ^(ActionSheetStringPicker *picker, NSInteger selectedIndex, id selectedValue) {
//                    if ([sender respondsToSelector:@selector(setText:)]) {
//                        [sender performSelector:@selector(setText:) withObject:selectedValue];
//                    }
//
//                    
//                };

                
                NSString *num = [NSString stringWithFormat:@"%d", self.Settings.FileTableFontSize] ;
                
                [ActionSheetStringPicker showPickerWithTitle:@"Select a Font Size" 
                                                        rows:self.FontSizeArray 
                                            initialSelection:[self.FontSizeArray indexOfObject:num]
                                                      target:self 
                                                sucessAction:@selector(setFontSize:element:)
                                                cancelAction:nil 
                                                      origin:self.tabBarController.view];

            }
                break;
                
            default:
                break;
        }
        
        
    }
    
    
    [self.tableView deselectRowAtIndexPath:[self.tableView indexPathForSelectedRow] animated:YES];
}


- (void)setFontSize:(NSNumber *)selectedIndex element:(id)element {

    self.Settings.FileTableFontSize = [[FontSizeArray objectAtIndex:[selectedIndex intValue]] integerValue];
    NSLog(@"FontSize = %d", self.Settings.FileTableFontSize);
    
    
    [self.tableView reloadData];
}



- (void) alertClearAlbumArt{
    
    UIAlertView *myAlertView = [[UIAlertView alloc] initWithTitle:@"Clear AlbumArt?" message:@"" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"OK", nil];    
    myAlertView.tag = 10000;
    [myAlertView show];
    [myAlertView release];
    
}

- (void)alertClearID3Database{
    
    UIAlertView *myAlertView = [[UIAlertView alloc] initWithTitle:@"Clear ID3Database?" message:@"" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"OK", nil];
    myAlertView.tag = 20000;
    [myAlertView show];
    [myAlertView release];

}


- (void)alertClearPlaylistDatabase{
    UIAlertView *myAlertView = [[UIAlertView alloc] initWithTitle:@"Clear Playlist Database?" message:@"" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"OK", nil];
    myAlertView.tag = 30000;
    [myAlertView show];
    [myAlertView release];

    
}

- (void) alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    // 도큐먼트 디렉토리 위치 구하기 
    NSArray *docs 
    = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docPath 
    = [[docs objectAtIndex:0] stringByAppendingPathComponent:@"tmp"];
    
    NSLog(@"path = %@", docPath);
    
    NSFileManager *fm = [NSFileManager defaultManager];
    [fm changeCurrentDirectoryPath:docPath];
    
    NSArray *files = [fm contentsOfDirectoryAtPath:docPath error:nil];
    
    if(alertView.tag == 10000 && buttonIndex == 1){
        for (NSString *path in files) {
            if([[path pathExtension] isEqualToString:@"png"]){
                [fm removeItemAtPath:path error:nil];
            }
        }
    }else if(alertView.tag == 20000 && buttonIndex == 1){
        [fm removeItemAtPath:@"data.sqlite3" error:nil];
        
        
        
        self.navigationController.view.userInteractionEnabled = FALSE;
        self.view.userInteractionEnabled = FALSE;
        self.tabBarController.view.userInteractionEnabled = FALSE;
        
        
        loading = [LoadingView loadingViewInView:self.navigationController.view withTitle:@"Reloading Data..."];
        
        [loading performSelector:@selector(removeView)
                      withObject:nil
                      afterDelay:120.0];
        
        [NSThread detachNewThreadSelector:@selector(ThreadProcess) 
                                 toTarget:self 
                               withObject:nil]; 

        
        
        
        
        
    }else if(alertView.tag == 30000 && buttonIndex == 1){
        [fm removeItemAtPath:@"playlsts.sqlite3" error:nil];
        
        
    }
    
    
    
    [self.tableView deselectRowAtIndexPath:[self.tableView indexPathForSelectedRow] animated:YES];
    
}



- (void)ThreadProcess{
    NSAutoreleasePool *autoreleasepool = [[NSAutoreleasePool alloc] init];
    
    //이곳에 처리할 코드를 넣는다.
    
    // 도큐먼트 디렉토리 위치 구하기 
    NSArray *docs 
    = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docPath 
    = [docs objectAtIndex:0];
    NSString *tmpPath
    = [[docs objectAtIndex:0] stringByAppendingPathComponent:@"tmp"];
    
    
    NSLog(@"path = %@", docPath);
    
    NSFileManager *fm = [NSFileManager defaultManager];
    [fm changeCurrentDirectoryPath:docPath];
    
    sqlite3 *database;
    if (sqlite3_open([[tmpPath stringByAppendingPathComponent:@"data.sqlite3"] UTF8String], &database) == SQLITE_OK) {
        //        sqlite3_close(database);
        
        // 테이블 생성 없을 경우 새로 만듬
        char *errorMsg;
        NSString *createSQL 
        = @"CREATE TABLE IF NOT EXISTS ID3DATA (FILEPATH TEXT PRIMARY KEY, PATH TEXT, FILENAME TEXT, TITLE TEXT, ARTIST TEXT, ALBUM TEXT, LYRICS TEXT, DURATION TEXT);";
        
        if (sqlite3_exec (database, [createSQL UTF8String], NULL, NULL, &errorMsg) != SQLITE_OK) {
            sqlite3_close(database);
            NSAssert1(0, @"Error creating table: %s", errorMsg);
        }else{
            NSLog(@"Table created");
        }
        
    }
    
    
    
    NSLog(@"UpdateFileInfo");
    
    //        [fm changeCurrentDirectoryPath:[docs objectAtIndex:0]];
    NSDirectoryEnumerator *dirEnum = [fm enumeratorAtPath:docPath];
    
    if (sqlite3_open([[tmpPath stringByAppendingPathComponent:@"data.sqlite3"] UTF8String], &database)
        != SQLITE_OK) {
        sqlite3_close(database);
        NSAssert(0, @"Failed to open database");
    }
    
    NSString *file;

    while (file = [dirEnum nextObject]) {
        
        NSURL *fileurl = [NSURL fileURLWithPath:file];
        
        if([[[file pathExtension] uppercaseString] isEqualToString:@"MP3"] == FALSE) continue;   
        
        
        Id3db *id3 = [[Id3db alloc] initWithURL:fileurl];
        [id3 id3ForFileAtPath];
        
        
//        NSLog(@"id3.path :%@", file);
        
        char *update = "INSERT OR REPLACE INTO ID3DATA (FILEPATH, PATH, FILENAME, TITLE, ARTIST, ALBUM, LYRICS, DURATION) VALUES (?, ?, ?, ?, ?, ?, ?, ?);";
        
        
//        NSLog(@"update : %@", file);
        
        sqlite3_stmt *stmt;
        if (sqlite3_prepare_v2(database, update, -1, &stmt, nil) == SQLITE_OK) {
            
            // "/abc/def.mp3"
            sqlite3_bind_text(stmt, 1, [file UTF8String], -1, NULL);
            
            // "/abc"
            sqlite3_bind_text(stmt, 2, [[file stringByDeletingLastPathComponent] UTF8String], -1, NULL);
            
            // "def.mp3"
            sqlite3_bind_text(stmt, 3, [[file lastPathComponent] UTF8String], -1, NULL);
            
            sqlite3_bind_text(stmt, 4, [id3.title UTF8String], -1, NULL);          
            sqlite3_bind_text(stmt, 5, [id3.artist UTF8String], -1, NULL);          
            sqlite3_bind_text(stmt, 6, [id3.album UTF8String], -1, NULL);          
            sqlite3_bind_text(stmt, 7, [id3.lyrics UTF8String], -1, NULL);          
            sqlite3_bind_text(stmt, 8, [[NSString stringWithFormat:@"%f", id3.duration] UTF8String], -1, NULL);                      
            
//            NSLog(@"path : %@ title : %@ duration : %f",  file,id3.title ,id3.duration);

            
        }
        
        if (sqlite3_step(stmt) != SQLITE_DONE){
            NSLog(@"Update Error");
            //            NSAssert1(0, @"Error updating table: %s", errorMsg);
        }else{
            NSLog(@"Update Success");
        }
        sqlite3_finalize(stmt);
        
    }
    
    sqlite3_close(database);

    
    
    [loading removeView];


    
    self.navigationController.view.userInteractionEnabled = TRUE;
    self.view.userInteractionEnabled = TRUE;
    self.tabBarController.view.userInteractionEnabled = TRUE;
    
    
    [autoreleasepool release];
    NSLog(@"Thread Done");
    [NSThread exit];
    
}


//#pragma mark -
//#pragma mark Picker View Methods
//
//- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)thePickerView {
//	
//	return 1;
//}
//
//- (NSInteger)pickerView:(UIPickerView *)thePickerView numberOfRowsInComponent:(NSInteger)component {
//	
//	return [self.FontSizeArray count];
//}
//
//- (NSString *)pickerView:(UIPickerView *)thePickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
//	
//	return [FontSizeArray objectAtIndex:row];
//}
//
//- (void)pickerView:(UIPickerView *)thePickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
//    
////    [thePickerView setHidden:YES];
//    
//    self.Settings.FileTableFontSize = [[FontSizeArray objectAtIndex:row] integerValue];
//	NSLog(@"fontsize set = %@", [FontSizeArray objectAtIndex:row]);
////	NSLog(@"Selected Color: %@. Index of selected color: %i", [arrayColors objectAtIndex:row], row);
//}
//


@end
