//
//  Player.h
//  App1
//
//  Created by Han Eunsung on 11. 10. 1..
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "SettingsData.h"

#import <AVFoundation/AVFoundation.h>
#import <AudioToolbox/AudioToolbox.h>
#import <MediaPlayer/MPVolumeView.h>


@class PlaylistTable;
@class Id3db;

@interface MyMusicPlayer  : UIViewController <AVAudioPlayerDelegate, AVAudioSessionDelegate> {
    
    // 내부 전역변수 ? 자체호출 가능 
//    float           
    
    float           currentTimeSec;
    float           durationTimeSec;
    
    int             LoadingCount;
    int             index;
    int             OriginalIndex;
    int             RepeatState; // 0 : non, 1 : one play, 2 : one repeat, 3 : all repeat
    
    BOOL            firstResponder;
    BOOL            isRandom;
    BOOL            inBackground;
    BOOL            inAlbumView;
    BOOL            inLyrics;


//    NSString        *
    NSURL           *path;
    NSArray         *playlist;
    NSMutableArray  *RandomizeIndex;
    
    
//    AVAudioPlayer   *player;
    AVPlayer        *player;
    
    
    NSTimer         *Timer;
    
    UISlider        *Timeline;
    UIView          *FlipView;
    UIView          *Bottomview;
    UIView          *TopController;
    UILabel         *PlayCount;
    UILabel         *CurrentTime;
    UILabel         *ElapsedTime;
    
    UILabel         *SongSinger;
    UILabel         *SongTitle;
    UILabel         *SongAlbum;
        
    UITextView      *Lyrics;
    UIView          *LyricsView;
    
    UIImage         *PlayImage;
    UIImage         *PauseImage;
    UIImage         *AlbumArt;
    UIImage         *listButton;
    UIImageView     *AlbumArtView;
    UIButton        *PlayButton;
    UIButton        *RepeatButton;
    UIButton        *RandomButton;
    PlaylistTable   *listTable;
    
    NSArray         *playTime;
    NSArray         *playTitle;
    
    
//    UITableViewController *callerNavigationController;


    
}

// 프로퍼티는 self. 으로 찾아 사용가능

// 외부 호출 가능한 프로퍼티 변수

@property (nonatomic)                  int              index;
@property (nonatomic)                  int              OriginalIndex;
@property (nonatomic)                  BOOL             isRandom;
@property (nonatomic)                  BOOL             inAlbumView;
@property (nonatomic)                  BOOL             inLyrics;
@property (nonatomic)                  BOOL             interruptedWhilePlaying;

//@property (nonatomic, assign)          AVAudioPlayer    *player;
@property (nonatomic, assign)          AVPlayer         *player;

@property (nonatomic, retain)          NSArray          *playlist;
@property (nonatomic, retain)          NSMutableArray   *RandomizeIndex;
@property (nonatomic, retain)          NSURL            *path;
@property (nonatomic, retain)          UIImage          *PlayImage;
@property (nonatomic, retain)          UIImage          *PauseImage;

@property (nonatomic, retain)          NSArray          *playTime;
@property (nonatomic, retain)          NSArray          *playTitle;

@property (nonatomic, retain)          NSThread         *AlbumArtThread;

// 내부에서 UI 변경시 ibout 프로퍼티 선언

@property (nonatomic, retain)          UILabel          *SongSinger;
@property (nonatomic, retain)          UILabel          *SongTitle;
@property (nonatomic, retain)          UILabel          *SongAlbum;



@property (nonatomic, retain) IBOutlet UISlider         *Timeline;

@property (nonatomic, retain) IBOutlet UILabel          *PlayCount;
@property (nonatomic, retain) IBOutlet UILabel          *CurrentTime;
@property (nonatomic, retain) IBOutlet UILabel          *ElapsedTime;

@property (nonatomic, retain) IBOutlet UITextView       *Lyrics;
@property (nonatomic, retain) IBOutlet UIView           *LyricsView;

@property (nonatomic, retain) IBOutlet UIView           *Bottomview;
@property (nonatomic, retain) IBOutlet UIView           *FlipView;
@property (nonatomic, retain) IBOutlet UIView           *TopController;

@property (nonatomic, retain) IBOutlet UIButton         *RepeatButton;
@property (nonatomic, retain) IBOutlet UIButton         *RandomButton;
@property (nonatomic, retain) IBOutlet UIButton         *PlayButton;

@property (nonatomic, retain)          UIButton         *FlipButton;

@property (nonatomic, retain) IBOutlet UIImage          *AlbumArt;
@property (nonatomic, retain) IBOutlet UIImageView      *AlbumArtView;
@property (nonatomic, retain) IBOutlet UIImageView      *AlbumArtViewInvert;


@property (nonatomic, retain) MPVolumeView *volumeView;
@property (nonatomic, retain) IBOutlet UIView *volumeUIView;

@property (nonatomic, retain) SettingsData *cfgData;


+ (MyMusicPlayer *) sharedMusicPlayer;

- (id) initWithMediaItems:(NSArray *)items startPoint:(int)idx;

- (id) MediaItems:(NSArray *)items startPoint:(int)idx;

- (void) updateTime;

- (void) audioPlayerDidFinishPlaying;

- (void) registerForBackgroundNotifications;

- (void) PlayAtIndex:(int)NewIndex;

//- (UIImage *) artworksForFileAtPath:(NSString *)filepath;
- (UIImage *) artworksForFileAtPath:(Id3db *)id3item;

- (void) id3ForFileAtPath:(Id3db *)id3item;

//- (void) id3ForFileAtPath:(NSString *)filepath;

- (void) ThreadCalcPlaytime;

- (void) PlayerClose;

- (void) AudioSessionRegister;

- (void) InitializePlayer;

- (void) readyToPlay;

- (void) RandomIndex;

- (void) RouteButton;

- (void) TimelineImageSet;

- (void) RandomToggle;

- (void) onLockInfo;

- (void) offLockInfo;

// UI 에서 터치 동작 메소드 정의 

- (IBAction) Play:(id)sender;
- (IBAction) Prev:(id)sender;
- (IBAction) Next:(id)sender;
- (IBAction) moveProgressbar:(id)sender;
- (IBAction) toggleRepeat:(id)sender;
- (IBAction) toggleRandom:(id)sender;

// for future use
- (IBAction) toggleFlip:(id)sender;



@end
