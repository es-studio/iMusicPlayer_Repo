//
//  Player.m
//  App1
//
//  Created by Han Eunsung on 11. 10. 1..
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MyMusicPlayer.h"
#import <AVFoundation/AVAudioPlayer.h>
#import <Foundation/Foundation.h>
#import <AudioToolbox/AudioToolbox.h>

#import <MediaPlayer/MPVolumeView.h>

#import <MediaPlayer/MPNowPlayingInfoCenter.h>
#import <MediaPlayer/MPMediaItem.h>



#import "PlaylistTable.h"
#import "PlaylistTableCell.h"
#import "Id3db.h"
#import "FileTable.h"

@implementation MyMusicPlayer

@synthesize index, OriginalIndex;
@synthesize isRandom, inAlbumView, inLyrics;
@synthesize player;
@synthesize playlist;
@synthesize path;
@synthesize PlayCount;
@synthesize PlayButton;
@synthesize PlayImage;
@synthesize PauseImage;
@synthesize CurrentTime;
@synthesize ElapsedTime;
@synthesize Timeline;
@synthesize Bottomview;
@synthesize RandomButton;
@synthesize RepeatButton;
@synthesize FlipView;
@synthesize FlipButton;
@synthesize AlbumArt;
@synthesize AlbumArtView, AlbumArtViewInvert;
@synthesize TopController;
@synthesize SongAlbum, SongTitle, SongSinger;
@synthesize RandomizeIndex;
@synthesize Lyrics, LyricsView;
@synthesize playTime, playTitle;
@synthesize AlbumArtThread;

@synthesize volumeView;
@synthesize volumeUIView;

@synthesize cfgData;
@synthesize interruptedWhilePlaying;

//void RouteChangeListener(void *                  inClientData,
//                         AudioSessionPropertyID	 inID,
//                         UInt32                  inDataSize,
//                         const void *            inData);

void RouteChangeListener(void *                  inClientData,
                         AudioSessionPropertyID	 inID,
                         UInt32                  inDataSize,
                         const void *            inData)
{
	MyMusicPlayer* This = (MyMusicPlayer *)inClientData;
	if (inID == kAudioSessionProperty_AudioRouteChange) {
		CFDictionaryRef routeDict = (CFDictionaryRef)inData;
		NSNumber* reasonValue = (NSNumber*)CFDictionaryGetValue(routeDict, CFSTR(kAudioSession_AudioRouteChangeKey_Reason));
		int reason = [reasonValue intValue];
        
        NSLog(@"Interrupt Reason = %d", reason);

        
		if (reason == kAudioSessionRouteChangeReason_OldDeviceUnavailable) {
            NSLog(@"Interrupt stop");
			[This Play:nil];
        }else if(reason == kAudioSessionRouteChangeReason_NewDeviceAvailable){
            NSLog(@"Interrupt New Device ");
            [This RouteButton];
            
        }
        
	}
}

static MyMusicPlayer *sharedPlayer;


#pragma mark - Initialize singleton

+ (MyMusicPlayer *)sharedMusicPlayer{
    
    // init Singletone
    if (sharedPlayer == nil) {
        sharedPlayer = [[MyMusicPlayer alloc] init];
        NSLog(@"MyMusicPlayer Singleton Created");
    }else{
        NSLog(@"MyMusicPlayer Singleton already Created");
    }
    return sharedPlayer;
}

#pragma mark - Initialize class

- (void)RouteButton{
    
    
    
    for (UIButton *button in volumeView.subviews) {
        
        
    //        if (volumeView.showsRouteButton == TRUE && [button isKindOfClass:[UIButton class]]) {
//        if ([button isKindOfClass:[UIButton class]]) {
//            
//            [button removeFromSuperview];
//        
//            [self.volumeUIView addSubview:button];
//            
//            CGRect rct = button.bounds;
//            rct.size = CGSizeMake(40, 30);
//            rct.origin = CGPointMake(0, 0);
//            button.bounds = rct;
////            
//            
//            [button sizeThatFits:CGSizeMake(40, 30)];

            
            
    //            [button sizeToFit];
            
//        }
    }
    
}

- (void) TimelineImageSet{
    for (UIView *view in volumeView.subviews) {
        if([view isKindOfClass:[UISlider class]]){
            UISlider *slider = (UISlider *)view;
            UIImage *max = [slider maximumTrackImageForState:UIControlStateNormal];
            UIImage *min = [slider minimumTrackImageForState:UIControlStateNormal];
            UIImage *thum = [slider thumbImageForState:UIControlStateNormal];
            [Timeline setMaximumTrackImage:max forState:UIControlStateNormal];
            [Timeline setMinimumTrackImage:min forState:UIControlStateNormal];
            [Timeline setThumbImage:thum forState:UIControlStateNormal];
            [Timeline setThumbImage:thum forState:UIControlStateSelected];
            [Timeline setThumbImage:thum forState:UIControlStateHighlighted];
        }
    }
}

- (void) RandomIndex{
    // 랜덤 플레이 리스트 초기화
    NSMutableArray *rlist = [NSMutableArray array];
    RandomizeIndex = [[NSMutableArray alloc] init];
    
    for (int i=0; i < [playlist count];i++) 
        [rlist addObject:[NSNumber numberWithInt:i]];
    
    while ([rlist count] != 0) {
        int rdm = arc4random() % [rlist count];
        [RandomizeIndex addObject:[rlist objectAtIndex:rdm]];
        [rlist removeObjectAtIndex:rdm];
    }
    
    
//    NSLog(@"Random Index = %@",RandomizeIndex);

}

- (void) popView{
    
    [self.navigationController popViewControllerAnimated:YES];
}

- (void) InitializePlayer{
    NSLog(@"Init Player");
    //--------------------------------------------------------------------
    // init variants
    self.view.backgroundColor = [UIColor blackColor] ;
    FlipView.backgroundColor = [UIColor blackColor];
    
    // playlist make
    listTable = [[PlaylistTable alloc] initWithNibName:@"PlaylistTable" bundle:nil];
    CGRect bounds = listTable.view.bounds;
    bounds.size.height = 365;
    listTable.view.bounds = bounds;
    [listTable setMplayer:self];
    listTable.view.hidden = TRUE;
    
    // flipbutton 이미지 
    listButton = [[UIImage imageNamed:@"listbutton.png"] copy];
    
    FlipButton = [UIButton buttonWithType:UIButtonTypeCustom];
    FlipButton.bounds = CGRectMake( 0, 0, listButton.size.width / 2, listButton.size.height / 2);    
    [FlipButton setImage:listButton forState:UIControlStateNormal];    
    [FlipButton addTarget:self action:@selector(toggleFlip:) forControlEvents:UIControlEventTouchUpInside];

    // 플립버튼    
    UIBarButtonItem *rightButton = [[[UIBarButtonItem alloc] initWithCustomView:FlipButton] autorelease];
    self.navigationItem.rightBarButtonItem = rightButton;
    
    
    UIImage *backImage = [UIImage imageNamed:@"back.png"];
    UIButton *backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [backBtn addTarget:self action:@selector(popView) forControlEvents:UIControlEventTouchUpInside];
    backBtn.bounds = CGRectMake(0, 0, 43, 31);
    [backBtn setImage:backImage forState:UIControlStateNormal];
    UIBarButtonItem *leftButton = [[[UIBarButtonItem alloc] initWithCustomView:backBtn] autorelease];
    
    self.navigationItem.leftBarButtonItem = leftButton;

    
    
    // background noti
    [self registerForBackgroundNotifications];
    
    // 하단 컨트롤 부분 그림
    UIImage *BottomImg = [UIImage imageNamed:@"bottom7.png"];
    CGSize newSize = CGSizeMake(320, 98);  //whaterver size
    UIGraphicsBeginImageContext(newSize);
    [BottomImg drawInRect:CGRectMake(0, 0, newSize.width, newSize.height)];
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();    
    UIGraphicsEndImageContext();
    Bottomview.backgroundColor = [UIColor colorWithPatternImage:newImage];
    Bottomview.alpha = 0.87;

    
    
    // 상단 상태바 검은색
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleBlackOpaque animated:YES];
    
    // 랜덤아이콘 리피트 아이콘 설정 
    [RepeatButton setImage:[UIImage imageNamed:@"Repeat_x.PNG"] forState:UIControlStateNormal];
    [RandomButton setImage:[UIImage imageNamed:@"Random_x.PNG"] forState:UIControlStateNormal];
    RepeatButton.titleLabel.text = @"";
    RandomButton.titleLabel.text = @"";
    
    // 반복 상태 0 : non
    RepeatState = 0;
    
    // 백그라운드 플레이 설정 ?
    firstResponder = YES;
    
    // 이미지 등록    
    PlayImage = [[UIImage imageNamed:@"play.png"] retain];
    PauseImage = [[UIImage imageNamed:@"pause.png"] retain];
    [PlayButton setImage:PlayImage  forState:UIControlStateNormal];
    

    if(volumeView == nil){
        volumeView = [[[MPVolumeView alloc] initWithFrame:CGRectMake(0, 0, 260, 20)] autorelease];
        volumeView.center = CGPointMake(160,390);
        [volumeView sizeToFit];
        [self.view addSubview:volumeView];

    }
    
    
    [self TimelineImageSet];
    //    self.AlbumArtThread = [[NSThread alloc] initWithTarget:self selector:@selector(ThreadCalcPlaytime) object:nil];
    //    [self.AlbumArtThread start];

}

- (void) AudioSessionRegister{
    
    // Audio Session Register
    AudioSessionInitialize(NULL,NULL,NULL,NULL);
	[[AVAudioSession sharedInstance] setDelegate: self];
	[[AVAudioSession sharedInstance] setCategory: AVAudioSessionCategoryPlayback error:nil];
    AudioSessionAddPropertyListener (kAudioSessionProperty_AudioRouteChange, RouteChangeListener, self);
}

- (id) MediaItems:(NSArray *)items startPoint:(int)idx{
    NSLog(@"MediaItems()");
    
    // 객체가 살아있을 경어만 특별히 종료 선행 작업 
    if(self.player) {        
        NSLog(@"No created Player First run");
        
        [self PlayerClose];
        
        [listTable.view removeFromSuperview];
        [listTable release];
        
        // 앨범모드로 종료되어 있을 경우 
        if(inAlbumView == FALSE){
            NSLog(@"inAlbumView false");
            inAlbumView = TRUE;
            if (inLyrics == TRUE) {
                LyricsView.hidden = NO;
                Lyrics.hidden     = NO;
                Lyrics.alpha = 1;
                LyricsView.alpha = 0.7;
            }
            
            NSLog(@"albumaview");
            FlipView.backgroundColor  = [UIColor blackColor];
            AlbumArtView.hidden       = NO;
            AlbumArtViewInvert.hidden = NO;
            TopController.hidden      = NO;
            [FlipView insertSubview:AlbumArtView atIndex:0];
            [FlipView insertSubview:AlbumArtViewInvert atIndex:1];
            
        }
    }
    
    //------------------------------------------------------- 
    // 초기설정 
    [self InitializePlayer];
    
    // 플레이리스트 가져오기
    self.playlist = [[NSArray alloc] initWithArray:items]; // id3db item array copy
    self.index = idx;
    self.OriginalIndex = idx;
    
    // 랜덤 인덱스 생성
    [self RandomIndex];
    
    // id3 item 
    Id3db *id3item = [self.playlist objectAtIndex:self.index];
    
//    self.player = [[AVAudioPlayer alloc] initWithContentsOfURL:[id3item.asset URL] error:&error];
    
    NSLog(@"Play URL = %@", [id3item.asset URL]);
    self.player = [[AVPlayer alloc] initWithURL:[id3item.asset URL]];
        
    // insert default image    
    AlbumArt = [self artworksForFileAtPath:[playlist objectAtIndex:index]];
    AlbumArtView.image       = AlbumArt;
    AlbumArtViewInvert.image = AlbumArt;
    AlbumArtViewInvert.transform = CGAffineTransformMakeRotation(1 * 3.14); // 180 deg
    AlbumArtViewInvert.transform = CGAffineTransformMakeScale(1, -1);

    inAlbumView = TRUE;
    
    
//    // Flitbutton set
//    FlipButton.imageView.image = nil;
//    [FlipButton setBackgroundColor:[UIColor clearColor]];
//    
//    // listButton 문제 있음 이미지를 백그라운드에도 돌아오면 다시 불러와야할것 같다
//    [FlipButton setImage:listButton forState:UIControlStateNormal];
    
    // Set Time
    CMTime currentTime = self.player.currentTime;    
    currentTimeSec = currentTime.value / currentTime.timescale;
    CMTime duration = self.player.currentItem.asset.duration;
    durationTimeSec = duration.value / duration.timescale;
    
    // timeline set
    CurrentTime.text 
    = [NSString stringWithFormat:@"%01d:%02d", (int)currentTimeSec / 60, (int)currentTimeSec % 60, nil];
    ElapsedTime.text 
    = [NSString stringWithFormat:@"-%01d:%02d", (int)(durationTimeSec - currentTimeSec) / 60, (int)(durationTimeSec - currentTimeSec) % 60, nil];

    Timeline.value = 0;
    Timeline.maximumValue = durationTimeSec;
    
    // ipod audio register for background play
    [self AudioSessionRegister];
    
    // 플레이 
    [self Play:nil];

    
    
    return self;

}

- (id) initWithMediaItems:(NSArray *)items startPoint:(int)idx{
    
    NSLog(@"InitWith media item");
    
    // init
    self.playlist = [[NSArray alloc] initWithArray:items]; // id3db item array
    self.index = idx;
    self.OriginalIndex = idx;
    
    // id3 item 
    Id3db *id3item = [self.playlist objectAtIndex:self.index];
    self.player = [[AVPlayer alloc] initWithURL:[id3item.asset URL]];
//    self.player = [[AVAudioPlayer alloc] initWithContentsOfURL:[id3item.asset URL] error:nil];

    [self AudioSessionRegister];
    
    
    return self;
}

- (void) didReceiveMemoryWarning{
    // Releases the view if it doesn't have a superview.
    NSLog(@"Memeory Warning");
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle

- (void) viewDidLoad{
   
    NSLog(@"Viewdidload()");
    [super viewDidLoad];
    
}

- (void) viewDidUnload{
//    AlbumArtThread = nil;
//     player = nil;
//     playlist = nil;
//     path = nil;
//     volSlider = nil;
//     PlayCount = nil;
//     PlayButton = nil;
//     PlayImage = nil;
//     PauseImage = nil;
//     CurrentTime = nil;
//     ElapsedTime = nil;
//     Timeline = nil;
//     Bottomview = nil;
//     RandomButton = nil;
//     RepeatButton = nil;
//     FlipView = nil;
//     FlipButton = nil;
//     AlbumArt = nil;
//     AlbumArtView = nil;
//     TopController = nil;
//     SongTitle = nil; SongAlbum = nil; SongSinger = nil;
//     RandomizeIndex = nil;
//     Lyrics = nil; LyricsView = nil;
//     playTime = nil; playTitle = nil;
//
//    [self setAlbumArt:nil];
//    SongSinger = nil;
//    SongAlbum = nil;
    
    [super viewDidUnload];
    
    NSLog(@"ViewDidUnloaded");

    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void) viewWillAppear:(BOOL)animated{
    

    [self.navigationController.navigationBar setBarStyle:UIBarStyleBlackOpaque];
    
    // 최초 생성시에만 세팅
    if (!SongTitle) {
        SongSinger = [[UILabel alloc] initWithFrame:CGRectMake(60, 2, 200, 15)];
        SongTitle  = [[UILabel alloc] initWithFrame:CGRectMake(60, 15, 200, 15)];
        SongAlbum  = [[UILabel alloc] initWithFrame:CGRectMake(60, 28, 200, 15)];
        
        SongSinger.textColor = [UIColor grayColor];
        SongTitle.textColor  = [UIColor whiteColor];
        SongAlbum.textColor  = [UIColor grayColor];
        
        SongSinger.backgroundColor = [UIColor clearColor];
        SongTitle.backgroundColor = [UIColor clearColor];
        SongAlbum.backgroundColor = [UIColor clearColor];
        
        SongSinger.font = [UIFont boldSystemFontOfSize:12.0];
        SongTitle.font = [UIFont boldSystemFontOfSize:12.0];
        SongAlbum.font = [UIFont boldSystemFontOfSize:12.0];
                
        SongSinger.textAlignment = UITextAlignmentCenter;
        SongTitle.textAlignment = UITextAlignmentCenter;
        SongAlbum.textAlignment = UITextAlignmentCenter;
//    label.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.5];
    }
    
    SongSinger.alpha = 0;
    SongTitle.alpha = 0;
    SongAlbum.alpha = 0;
    
    // 네비게이션바에 넣기
    [self.navigationController.navigationBar addSubview:SongSinger];            
    [self.navigationController.navigationBar addSubview:SongTitle];            
    [self.navigationController.navigationBar addSubview:SongAlbum];   
    
    // 플레이리스트 객체에서 id3db 타입의 단일 파일 선택
    Id3db *id3item = [playlist objectAtIndex:index];
    SongTitle.text = id3item.title;
    SongAlbum.text = id3item.album;
    SongSinger.text = id3item.artist;


    [UIView animateWithDuration:1 animations:^{
        SongSinger.alpha = 1;
        SongTitle.alpha = 1;
        SongAlbum.alpha = 1;
        
        

    }];
    
    UIApplication *app = [UIApplication sharedApplication];
    [app setStatusBarStyle:UIStatusBarStyleBlackOpaque];
    
    
    
    

    [self RouteButton];
    
    
    
    
}

- (void) viewWillDisappear:(BOOL)animated{
    [self.navigationController.navigationBar setBarStyle:UIBarStyleDefault];
    
//    // 디렉토리 파일테이블일 경우 플레이 정지
//    NSArray *views = self.navigationController.viewControllers;
//    if([[views objectAtIndex:0] isMemberOfClass:[FileTable class]] == TRUE
//       && self.player.rate > 0.0){
//        
//        [self Play:nil];
//    }
    


    
    [UIView animateWithDuration:1 animations:^{
        [SongSinger removeFromSuperview];
        [SongTitle removeFromSuperview];
        [SongAlbum removeFromSuperview];
        

    }];
    
    UIApplication *app = [UIApplication sharedApplication];
    [app setStatusBarStyle:UIStatusBarStyleDefault];
    
    
    
}

- (void) viewDidAppear:(BOOL)animated{
    [[UIApplication sharedApplication] beginReceivingRemoteControlEvents];
    [self becomeFirstResponder];
    NSLog(@"ViewDidAppear");
    
}

- (void) viewDidDisappear:(BOOL)animated{
    NSLog(@"MyMusicPlayer DidDisappear");
}

- (void) dealloc {
    
    NSLog(@"MyMusicPlayer dealloc");
    [playlist release];
    
    [AlbumArtThread release];
    
    [path release];
    [PlayCount release];
    [PlayButton release];
    [PlayImage release];
    [PauseImage release];
    [CurrentTime release];
    [ElapsedTime release];
    [Timeline release];
    [Bottomview release];
    
    [RandomButton release];
    [RepeatButton release];
    [FlipView release];
    [FlipButton release];
    
    //    [AlbumArt release];
    
    [AlbumArtViewInvert release];
    [AlbumArtView release];
    [TopController release];
    [SongTitle release];
    [SongAlbum release];
    [SongSinger release];
    [RandomizeIndex release];
    [Lyrics release];
    [LyricsView release];
    [listTable release];
    
    [player release];
    [playlist release];
    [playTime release];
    [playTitle release];
    [AlbumArtThread release];
        
    
    //---------------------
    
    
    player = nil;
    AlbumArtThread = nil;
    path = nil;
    
    PlayCount = nil;
    
    PlayButton = nil;
    
    PlayImage = nil;
    PauseImage = nil;
    
    CurrentTime = nil;
    
    ElapsedTime = nil;
    
    Timeline = nil;
    Bottomview = nil;
    
    RandomButton = nil;
    
    FlipView = nil;
    FlipButton = nil;
    
    //    [AlbumArt release];
    
    AlbumArtViewInvert = nil;
    AlbumArtView = nil;
    TopController = nil;
    SongTitle = nil;
    
    SongAlbum = nil;
    
    SongSinger = nil;
    RandomizeIndex = nil;
    
    Lyrics = nil;
    LyricsView = nil;
    
    listTable = nil;
    
    player = nil;
    playlist = nil;
    playTime = nil;
    
    playTime = nil;
    playTitle = nil;
    
    
        
    NSLog(@"super = %@", [super class]);
    //[super dealloc];
}

- (BOOL) shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - AudioPlaying Action

- (void) audioPlayerDidFinishPlaying{
    NSLog(@"RepeatState = %d", RepeatState);
    switch (RepeatState) {
            
        case 0: // non-repeat
            
//            NSLog(@"index : %d / %d ", index, [playlist count]);
            if(index + 1 == [playlist count]){
                
                [Timer invalidate];
                Timer = nil;

                [self.player seekToTime:CMTimeMake(0, self.player.currentTime.timescale)];
                Timeline.value = 0;
                [self.player pause]; // stop
                
                
                CGRect oldframe = PlayButton.frame;
                oldframe.size = CGSizeMake(40, 32);
                oldframe.origin = CGPointMake(140, 6);
                PlayButton.frame = oldframe;
                [PlayButton setImage:PlayImage forState:UIControlStateNormal];
                
            }else{
                [self Next:@""];
            }
            break;
            
        case 1: // play 1

            [Timer invalidate];
            Timer = nil;

            Timeline.value = 0;
            [self.player seekToTime:CMTimeMake(0, self.player.currentTime.timescale)];
            [self.player pause]; // stop
            
            CGRect oldframe = PlayButton.frame;
            oldframe.size = CGSizeMake(40, 32);
            oldframe.origin = CGPointMake(140, 6);
            PlayButton.frame = oldframe;
            [PlayButton setImage:PlayImage  forState:UIControlStateNormal];
            

            break;
            
        case 2: // repeat 1
            
            [self Next:nil];
            
            break;
            
        case 3: // repeat all
            
//            if(index + 1 == [playlist count]){
//                index = 0;
//            }else{
//                index++;
//            }
            [self Next:@""];
            
            break;
            
        default:
            break;
    }
    
    

    
    
}

- (void) audioPlayerBeginInterruption:(AVAudioPlayer *)p{
	NSLog(@"Interruption begin. Updating UI for new state");
	// the object has already been paused,	we just need to update UI
    [self Play:nil];

}

- (void) audioPlayerEndInterruption:(AVAudioPlayer *)p{
	NSLog(@"Interruption ended. Resuming playback");
    
    [self Play:nil];

}

#pragma mark - Player 

- (void) ThreadCalcPlaytime{
    NSAutoreleasePool *autoreleasepool = [[NSAutoreleasePool alloc] init];
    //이곳에 처리할 코드를 넣는다.
    NSMutableArray *DurationArray = [[NSMutableArray alloc] init];
    NSMutableArray *TitleArray = [[NSMutableArray alloc] init]; 
    
    LoadingCount = 0;
    
    for (NSString *item in playlist) {
        
        AVURLAsset *asset = [[[AVURLAsset alloc] initWithURL:[NSURL fileURLWithPath:item] options:nil] autorelease];
        
        // getting playtime
        int duration = asset.duration.value / asset.duration.timescale;
        NSString *strDuration = [NSString stringWithFormat:@"%02d:%02d", duration / 60, duration % 60];
        [DurationArray addObject:strDuration];
        
        
        // getting title;
        NSArray *formatArray = asset.availableMetadataFormats; // get org.id3
        
        NSString *title = @"";
        
        if ([formatArray count] != 0 ) {
            
            NSArray *array = [asset metadataForFormat:[formatArray objectAtIndex:0]]; //for get id3 tags
            
            for(AVMetadataItem *metadata in array) { 
                if([metadata.commonKey isEqualToString:@"title"]){
                    title = metadata.stringValue;
                }
            }
        }
        if([title isEqualToString:@""]) {
            title = [[item lastPathComponent] stringByDeletingPathExtension];                
        }
        [TitleArray addObject:title];
        
        LoadingCount++;
        
    }
    
    playTitle = TitleArray;
    playTime = DurationArray;
    [autoreleasepool release];
    
    FlipButton.enabled = TRUE;
    
    
    
    NSLog(@"Thread Done");
    [NSThread exit];
}

- (void) TimerOn{
    
    Timer = [NSTimer scheduledTimerWithTimeInterval:0.25 
                                             target:self 
                                           selector:@selector(updateTime) 
                                           userInfo:self.player 
                                            repeats:YES];
}

- (void) updateTime{
    //    NSLog(@"time!");
    
    CMTime currentTime = self.player.currentTime;    
    currentTimeSec = currentTime.value / currentTime.timescale;
    
    if(self.player.rate > 0.0){
        
        CurrentTime.text 
        = [NSString stringWithFormat:@"%01d:%02d", (int)currentTimeSec / 60, (int)currentTimeSec % 60, nil];
        ElapsedTime.text 
        = [NSString stringWithFormat:@"-%01d:%02d", (int)(durationTimeSec - currentTimeSec) / 60, (int)(durationTimeSec - currentTimeSec) % 60, nil];
        
        Timeline.value = currentTimeSec;
        
    }else{
        
        
    }

    
//    if(self.player.playing == TRUE){
//        
//        CurrentTime.text = [NSString stringWithFormat:@"%01d:%02d", (int)self.player.currentTime / 60, (int)self.player.currentTime % 60, nil];
//        
//        
//        int CurrentPlayTime = self.player.currentTime;
//        ElapsedTime.text = [NSString stringWithFormat:@"-%01d:%02d", (int)(self.player.duration - CurrentPlayTime) / 60, (int)(self.player.duration - CurrentPlayTime) % 60, nil];
//        
//        Timeline.value = self.player.currentTime;
//        
//    }else{
//        
//        
//    }
    
}

- (void) PlayAtIndex:(int)NewIndex{
    
    // for playlist
    PlaylistTableCell *orig_cell = (PlaylistTableCell *)[listTable.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:index inSection:0]];
    
    index = OriginalIndex = NewIndex;
    PlayCount.text = [NSString stringWithFormat:@"%d/%d", index + 1, [playlist count] ];
    Id3db *id3item = [playlist objectAtIndex:index];  
    AlbumArt = [self artworksForFileAtPath:id3item];
    
    
    [Timer invalidate];
    Timer = nil;
    [self.player pause];
    
    [self.player release];
    self.player = [[AVPlayer alloc] initWithURL:[id3item.asset URL]];
//    self.player = [[AVAudioPlayer alloc] initWithContentsOfURL:[id3item.asset URL] error:nil];
    [self Play:nil];
    
    // for playlist 
    PlaylistTableCell *next_cell = (PlaylistTableCell *)[listTable.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:index inSection:0]];
    
    orig_cell.HereImage.hidden = TRUE;
    next_cell.HereImage.hidden = FALSE;
    [orig_cell release];
    [next_cell release];
    
    
    [listTable.tableView deselectRowAtIndexPath:[NSIndexPath indexPathForRow:index inSection:0] animated:YES];
    
    
    AlbumArtView.image       = AlbumArt;
    AlbumArtViewInvert.image = AlbumArt;
    AlbumArtViewInvert.transform = CGAffineTransformMakeRotation(1 * 3.14); // 180 deg
    AlbumArtViewInvert.transform = CGAffineTransformMakeScale(1, -1);




}

- (void) readyToPlay{
    
//    player.volume = volSlider.value;
//    
//    if (Timer > 0) {
//        [Timer invalidate];
//    }
//    
//    
//    // 딜리게이트롤 자신으로
//    player.delegate = self;
//    
//    [player prepareToPlay];
//    
//    Timeline.maximumValue = self.player.duration;
//    
//    
//    CGRect oldframe = PlayButton.frame;
//    
//    oldframe.size = CGSizeMake(28, 32);
//    oldframe.origin = CGPointMake(146, 6);
//    PlayButton.frame = oldframe;
//    [PlayButton setImage:PlayImage  forState:UIControlStateNormal];
    
}

- (void) PlayerClose{
    [self.player pause];
    [Timer invalidate];    
    Timer = nil;
    index = isRandom = inLyrics = 0;
    
}

- (void)onLockInfo{
 
    // lock screen image
    MPMediaItemArtwork *mediaArtwork = [[[MPMediaItemArtwork alloc] initWithImage:AlbumArt] autorelease];
    MPNowPlayingInfoCenter *nowPlaying = [MPNowPlayingInfoCenter defaultCenter];
    NSMutableDictionary *myDic = [NSMutableDictionary dictionary];
    
    Id3db *id3item = [playlist objectAtIndex:index];
    
    [myDic setObject:id3item.title forKey:MPMediaItemPropertyTitle];
    [myDic setObject:id3item.artist forKey:MPMediaItemPropertyArtist];
    [myDic setObject:id3item.album forKey:MPMediaItemPropertyAlbumTitle];
    [myDic setObject:mediaArtwork forKey:MPMediaItemPropertyArtwork];
    [nowPlaying setNowPlayingInfo:myDic];
    
}

- (void)offLockInfo{

    // lock screen image
    MPNowPlayingInfoCenter *nowPlaying = [MPNowPlayingInfoCenter defaultCenter];    
    [nowPlaying setNowPlayingInfo:nil];
}

#pragma mark - IBAction

- (IBAction) Play:(id)sender{
    NSLog(@"play()");
    
    // 인터럽트 해제 
    self.interruptedWhilePlaying = FALSE;


    // 타이머가 사용가능하고 nil 이 아닐 때 : 재생중 다시 재생이 호출될 때 타이머 멈춤
    // Timer 는 외부에 의해 자주 nil 된다.
    if (Timer != nil && Timer.isValid == TRUE) {
        NSLog(@"Timer Stop");
        [Timer invalidate];
        
        // 타이머 제거 후 일시정지
        Timer = nil;
        [self.player pause];    
        NSLog(@"Player Paused");
        CGRect oldframe = PlayButton.frame;
        oldframe.size = CGSizeMake(40, 32);
        oldframe.origin = CGPointMake(140, 6);
        PlayButton.frame = oldframe;
        [PlayButton setImage:PlayImage forState:UIControlStateNormal];
        
        // 타이버 멈추가 일시정지후 나가가ㅣ
        return;

    }
    
//    NSLog(@"player rate = %f", self.player.rate);
    // 재생 중일 경우 : 일시정지
//    if(self.player.playing == YES)
    if(self.player.rate > 0.0)
    {
        // 타이머 제거 후 일시정지
        Timer = nil;
        [self.player pause];    
        NSLog(@"Player Paused");
        CGRect oldframe = PlayButton.frame;
        oldframe.size = CGSizeMake(40, 32);
        oldframe.origin = CGPointMake(140, 6);
        PlayButton.frame = oldframe;
        [PlayButton setImage:PlayImage forState:UIControlStateNormal];
        
    }
    // 재생 중이지 않는 경우 : 재생모드
    else{
        
        // 플레이어 시작
        [self.player play];
        
        
        CMTime duration = self.player.currentItem.asset.duration;
        durationTimeSec = duration.value / duration.timescale;
        Timeline.maximumValue = durationTimeSec;
        
        // 타이머 시작
        if(Timer == nil) {
            NSLog(@"timer on");
            [self TimerOn];
        }
        
        // 플레이 버튼 일시정지로
        CGRect oldframe = PlayButton.frame;
        oldframe.size = CGSizeMake(28, 32);
        oldframe.origin = CGPointMake(146, 6);
        PlayButton.frame = oldframe;
        
        // 재생중이므로 일시정지 그림을 보여준다
        [PlayButton setImage:PauseImage  forState:UIControlStateNormal];

        // 플레이리스트 객체에서 id3db 타입의 단일 파일 선택
        Id3db *id3item = [playlist objectAtIndex:index];
        SongTitle.text = id3item.title;
        SongAlbum.text = id3item.album;
        SongSinger.text = id3item.artist;

        PlayCount.text = [NSString stringWithFormat:@"%d/%d", index + 1, [playlist count] ];
        
        // 재생목록 테이블에서 해당 파일 선택후 선택 해제
        [listTable.tableView selectRowAtIndexPath:[NSIndexPath indexPathForRow:index inSection:0] 
                                         animated:YES scrollPosition:UITableViewScrollPositionNone];
        [listTable.tableView deselectRowAtIndexPath:[NSIndexPath indexPathForRow:index inSection:0] 
                                           animated:YES];
        
        
        cfgData = [SettingsData sharedSettingsData];
        if(cfgData.OnLockScreenInfo == TRUE) {
            
            [self onLockInfo];
            
        }else{
            
            [self offLockInfo];
            
        }
        
        
        
        NSLog(@"LockScreenInfo : %d", cfgData.OnLockScreenInfo);
        
        // 테이블 화면 일경우 우상단 버튼의 이미지를 앨범 아트로 변경 
        if(inAlbumView == FALSE){
            [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
                FlipButton.imageView.alpha = 0;                
            } completion:^(BOOL complete){
                [UIView animateWithDuration:0.5 animations:^{
                    [FlipButton setImage:AlbumArt forState:UIControlStateNormal];
                    FlipButton.imageView.alpha = 1;
                }];
            }];
        } //end if
        
        //remove noti
        [[NSNotificationCenter defaultCenter] removeObserver:self 
                                                        name:AVPlayerItemDidPlayToEndTimeNotification 
                                                      object:nil];
        
        //regist noti
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(audioPlayerDidFinishPlaying)
                                                     name:AVPlayerItemDidPlayToEndTimeNotification
                                                   object:nil];
        
        
    }
    
}

- (IBAction) Prev:(id)sender{
    
    
    // for playlist
    PlaylistTableCell *orig_cell = (PlaylistTableCell *)[listTable.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:index inSection:0]];
    
    
    if(sender != nil){
        if(OriginalIndex - 1 < 0) index = OriginalIndex = [playlist count] - 1; 
        else index = --OriginalIndex;
        if(isRandom) index = [(NSNumber *)[RandomizeIndex objectAtIndex:OriginalIndex] intValue];
    }
    
    
    PlayCount.text = [NSString stringWithFormat:@"%d/%d", index + 1, [playlist count] ];
    
    Id3db *id3item = [playlist objectAtIndex:index]; 
    AlbumArt = [self artworksForFileAtPath:id3item];
    AlbumArtViewInvert.image = AlbumArt;
    AlbumArtViewInvert.transform = CGAffineTransformMakeRotation(1 * 3.14); // 180 deg
    AlbumArtViewInvert.transform = CGAffineTransformMakeScale(1, -1);

    
    
    [Timer invalidate];
    Timer = nil;
    [self.player pause];
    
    
    // for playlist 
    PlaylistTableCell *next_cell = (PlaylistTableCell *)[listTable.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:index inSection:0]];
    
    orig_cell.HereImage.hidden = TRUE;
    next_cell.HereImage.hidden = FALSE;
    
    if(inAlbumView){
    
        [UIView transitionWithView:FlipView 
                          duration:1 
                           options:UIViewAnimationOptionTransitionCurlDown 
                        animations:^{
                            
                            AlbumArtView.image = AlbumArt;
                            
                        } 
                        completion:^(BOOL sucess){
                        }
         ];

    }
    
    //play now!
    [self.player release];
    self.player = [[AVPlayer alloc] initWithURL:[id3item.asset URL]];
//    self.player = [[AVAudioPlayer alloc] initWithContentsOfURL:[id3item.asset URL] error:nil];
    [self Play:nil];
    
    
}

- (IBAction) Next:(id)sender{
    
    // for playlist
    PlaylistTableCell *orig_cell = (PlaylistTableCell *)[listTable.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:index inSection:0]];
    
//    NSLog(@"Random Index = %@",RandomizeIndex);
    
    // 직접 다음을 터치하는 경우는 무조건 다음 트랙으로 넘김
    if(sender != nil){
        if(OriginalIndex + 1 >= [playlist count]) index = OriginalIndex = 0; 
        else index = ++OriginalIndex;
        if(isRandom == TRUE) index = [(NSNumber *)[RandomizeIndex objectAtIndex:OriginalIndex] intValue];
    }
    
    
    PlayCount.text = [NSString stringWithFormat:@"%d/%d", index + 1, [playlist count] ];
    
    Id3db *id3item = [playlist objectAtIndex:index];    
    AlbumArt = [self artworksForFileAtPath:id3item];
    AlbumArtViewInvert.image = AlbumArt;
    AlbumArtViewInvert.transform = CGAffineTransformMakeRotation(1 * 3.14); // 180 deg
    AlbumArtViewInvert.transform = CGAffineTransformMakeScale(1, -1);

    
    if(Timer.isValid == TRUE){
        [Timer invalidate];
        Timer = nil;
    }
    
    // for playlist 
    PlaylistTableCell *next_cell = (PlaylistTableCell *)[listTable.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:index inSection:0]];
    
    orig_cell.HereImage.hidden = TRUE;
    next_cell.HereImage.hidden = FALSE;
    
    
    if(inAlbumView){
        
        [UIView transitionWithView:FlipView 
                          duration:1 
                           options:UIViewAnimationOptionTransitionCurlUp
                        animations:^{
                        
                            AlbumArtView.image = AlbumArt;
                        
                        } 
                        completion:^(BOOL sucess){
                        }
         ];
        
    
    }
    
    // Play now!
    [self.player pause];
    [self.player release];

    self.player = [[AVPlayer alloc] initWithURL:[id3item.asset URL]];
//    self.player = [[AVAudioPlayer alloc] initWithContentsOfURL:[id3item.asset URL] error:nil];
    
    [self Play:nil];
    
    
    
    
    
}

- (IBAction) moveProgressbar:(id)sender{
    
    UISlider *slider = (UISlider *)sender;
    float scale = self.player.currentTime.timescale;
    
    if ((int)slider.value % 2 == 0){
        [self.player seekToTime:CMTimeMake(slider.value * scale, scale)];
    }
    
    
}

- (IBAction) toggleRepeat:(id)sender{
    
    RepeatState++;
    if (RepeatState > 3) RepeatState = 0;
    
    [RepeatButton setImage:nil forState:UIControlStateNormal];
    
    switch (RepeatState) {
        case 0:
            // non-repeat
            
            [RepeatButton setImage:[UIImage imageNamed:@"Repeat_x.PNG"] forState:UIControlStateNormal];
            
            break;
            
        case 1:
            // play 1
            
            [RepeatButton setImage:[UIImage imageNamed:@"Repeat_1.PNG"] forState:UIControlStateNormal];
            break;
            
        case 2:
            // repeat 1
            
            [RepeatButton setImage:[UIImage imageNamed:@"Repeat_o.PNG"] forState:UIControlStateNormal];
            break;
            
        case 3:
            // repeat all
            [RepeatButton setImage:[UIImage imageNamed:@"Repeat_a.PNG"] forState:UIControlStateNormal];
            break;
            
            
        default:
            break;
    }
    
    
    
}

- (void)RandomToggle{
    
    if(isRandom == NO){
        isRandom = YES;
        [RandomButton setImage:[UIImage imageNamed:@"Random_o.PNG"] forState:UIControlStateNormal];
        
    }else{
        isRandom = NO;
        [RandomButton setImage:[UIImage imageNamed:@"Random_x.PNG"] forState:UIControlStateNormal];
    }
    
    NSLog(@"Random : %d", isRandom);

    
}

- (IBAction) toggleRandom:(id)sender{
    
    [self RandomToggle];
}

- (IBAction) toggleFlip:(id)sender{
    NSLog(@"toggleFlip");
    
    CGRect p = listTable.view.bounds;
    listTable.view.bounds = p;    
    listTable.view.center = CGPointMake(p.size.width / 2, p.size.height / 2);
    
    if(inAlbumView == TRUE){
        inAlbumView = FALSE;
        
        [UIView transitionWithView:FlipView
                          duration:0.8 
                           options:UIViewAnimationOptionTransitionFlipFromRight
                        animations:^{
                            
                            listTable.view.hidden   = NO;
                            AlbumArtView.hidden     = YES;
                            AlbumArtViewInvert.hidden = YES;
                            TopController.hidden    = YES;
                            [AlbumArtView removeFromSuperview];
                            [AlbumArtViewInvert removeFromSuperview];
                            [listTable.tableView reloadData];
                            
                            [FlipView insertSubview:listTable.view atIndex:0];

                            
                            FlipView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bg4.png"]];

                        }
                        completion:nil
         ];
        
        
        
        
        AlbumArt = [self artworksForFileAtPath:[playlist objectAtIndex:index]];

        [UIView transitionWithView:FlipButton 
                          duration:0.8 
                           options:UIViewAnimationOptionTransitionFlipFromLeft
                        animations:^{
                            
                            // 테이블 뷰일경우 앨범 아트보기
                            [FlipButton setImage:AlbumArt forState:UIControlStateNormal];
                            
                            if (inLyrics == TRUE) {
                                LyricsView.hidden = YES;
                                Lyrics.hidden     = YES;
                            }

                        }
                        completion:^(BOOL ok){
            
                        }
         ];
                

    }else{
        inAlbumView = TRUE;
        
        NSLog(@"lyrics = %d", inLyrics);
        if (inLyrics == TRUE) {
            LyricsView.hidden = NO;
            Lyrics.hidden     = NO;
            Lyrics.alpha = 1;
            LyricsView.alpha = 0.7;
        }


        [UIView transitionWithView:FlipView
                          duration:0.8 
                           options:UIViewAnimationOptionTransitionFlipFromLeft
                        animations:^{
                            
                            FlipView.backgroundColor = [UIColor blackColor];
                            listTable.view.hidden   = YES;
                            AlbumArtView.hidden     = NO;
                            AlbumArtViewInvert.hidden = NO;
                            TopController.hidden    = NO;
                            [FlipView insertSubview:AlbumArtView atIndex:0];
                            [FlipView insertSubview:AlbumArtViewInvert atIndex:1];
                            [listTable.view removeFromSuperview];
                            
                        } 
                        completion:nil
         ];
        
        [UIView transitionWithView:FlipButton 
                          duration:0.8 
                           options:UIViewAnimationOptionTransitionFlipFromRight
                        animations:^{
                            
                            FlipButton.imageView.image = nil;
                            [FlipButton setBackgroundColor:[UIColor clearColor]];
                            
                            //listButton 문제 있음 이미지를 백그라운드에도 돌아오면 다시 불러와야할것 같다
                            [FlipButton setImage:listButton forState:UIControlStateNormal];

                        }
                        completion:nil
         ];
        
        
    }
    
}

#pragma mark - External Control

- (BOOL) canBecomeFirstResponder{
    
    //    return firstResponder;
    return YES;
}

- (void) remoteControlReceivedWithEvent:(UIEvent *)event{
    
//    UIEventSubtypeRemoteControlPlay                 = 100,
//    UIEventSubtypeRemoteControlPause                = 101,
//    UIEventSubtypeRemoteControlStop                 = 102,
//    UIEventSubtypeRemoteControlTogglePlayPause      = 103,
//    UIEventSubtypeRemoteControlNextTrack            = 104,
//    UIEventSubtypeRemoteControlPreviousTrack        = 105,
//    UIEventSubtypeRemoteControlBeginSeekingBackward = 106,
//    UIEventSubtypeRemoteControlEndSeekingBackward   = 107,
//    UIEventSubtypeRemoteControlBeginSeekingForward  = 108,
//    UIEventSubtypeRemoteControlEndSeekingForward    = 109,

    
    
    NSLog(@"event = %d", event.subtype);
    
    if(event.subtype == UIEventSubtypeRemoteControlTogglePlayPause){
        [self Play:event];
    }else if(event.subtype == UIEventSubtypeRemoteControlNextTrack){
        [self Next:event];
    }else if(event.subtype == UIEventSubtypeRemoteControlPreviousTrack){
        [self Prev:event];
    }
    
    
}

- (void) registerForBackgroundNotifications{
	[[NSNotificationCenter defaultCenter] addObserver:self
											 selector:@selector(setInBackgroundFlag)
												 name:UIApplicationWillResignActiveNotification
											   object:nil];
	
	[[NSNotificationCenter defaultCenter] addObserver:self
											 selector:@selector(clearInBackgroundFlag)
												 name:UIApplicationWillEnterForegroundNotification
											   object:nil];
}

- (void) setInBackgroundFlag{
    NSLog(@"in background");
	inBackground = true;
    

}

- (void) clearInBackgroundFlag{
    NSLog(@"No in background");
	inBackground = false;
    
    
}

#pragma mark - etc.

- (UIImage *) artworksForFileAtPath:(Id3db *)id3item{
    UIImage *img = [UIImage imageNamed:@"defaultAlbum.png"];
    
    // for get artwork image
    NSArray *array = [AVMetadataItem metadataItemsFromArray:id3item.asset.commonMetadata
                                                    withKey:AVMetadataCommonKeyArtwork 
                                                   keySpace:AVMetadataKeySpaceCommon];
    
    if([array count] == 0) img = [UIImage imageNamed:@"defaultAlbum.png"];
    
    for(AVMetadataItem *metadata in array) { 
        
        if ([metadata.commonKey isEqualToString:@"artwork"])
        {
            NSLog(@"in Artwork");
            NSDictionary *d = [metadata.value copyWithZone:nil];            
            img = [UIImage imageWithData:[d objectForKey:@"data"]];
            NSLog(@"img = %f %f", img.size.width, img.size.height);
        }
        
    }
    
    return img;
}

- (void) id3ForFileAtPath:(Id3db *)id3item{

//    AVURLAsset *asset = [[AVURLAsset alloc]initWithURL:[NSURL fileURLWithPath:filepath ] options:nil]; 
    
//    NSArray *formatArray = asset.availableMetadataFormats; // get org.id3
    NSArray *formatArray = id3item.asset.availableMetadataFormats; // get org.id3
    
    // 가사가 있을 경우
    if([[id3item.asset lyrics] length] > 0){
        
        // 가사 있음
        inLyrics = TRUE;
        
        Lyrics.text = [id3item.asset lyrics];
        [Lyrics scrollsToTop];
        
        // 앨범아트 모드일경우 
        if(inAlbumView == TRUE){

            Lyrics.hidden = FALSE;
            LyricsView.hidden = FALSE;
            
            // 가사 보기 애니메이션
            [UIView animateWithDuration:0.8 animations:^{
                
                Lyrics.alpha     = 1;
                LyricsView.alpha = 0.7;
                        
            }];
        }else{
            [UIView animateWithDuration:0.8 animations:^{
                
                Lyrics.alpha     = 0;
                LyricsView.alpha = 0;
                
            }];
        }
        
    }else {
        
        // 가사 없음
        inLyrics = FALSE;
        
        // 가사가 없을 경우 애니메이션
        [UIView animateWithDuration:0.8 animations:^{
        
            Lyrics.alpha      = 0;
            LyricsView.alpha  = 0;
        
        }];
    }

    NSString *title, *artist, *albumName;
    title = @"";
    artist = @"Unknown Artist";
    albumName = @"Unknown Album";

    
    if ([formatArray count] == 0 ) {
        SongAlbum.text = albumName;
        SongSinger.text = artist;
        
//        [asset release];
        return;
    }
    
    NSArray *array = [id3item.asset metadataForFormat:[formatArray objectAtIndex:0]]; //for get id3 tags

    for(AVMetadataItem *metadata in array) { 
        if ([metadata.commonKey isEqualToString:@"artwork"]){
            // 앨범아트 추출 못하는 경우가 많아 다른 메소드로 대체 
            NSDictionary *d = [metadata.value copyWithZone:nil];
            UIImage *img = [UIImage imageWithData:[d objectForKey:@"data"]];
            NSLog(@"img %f %f", img.size.width, img.size.height);            
        }
        else if([metadata.commonKey isEqualToString:@"title"]){
            
            title = metadata.stringValue;
        }
        else if([metadata.commonKey isEqualToString:@"artist"]){
            artist = metadata.stringValue;
        }
        else if([metadata.commonKey isEqualToString:@"albumName"]){
            albumName = metadata.stringValue;
        }
        
//        NSLog(@"Unknown : %@ %@ %@ %@",metadata.commonKey, metadata.dateValue, metadata.numberValue, metadata.stringValue);
    }
    
    if(![title isEqualToString:@""]) SongTitle.text = title;
    
    SongAlbum.text = albumName;
    SongSinger.text = artist;
    
//    [asset release];
    
}

#pragma mark - Audio Session Delegate

- (void)beginInterruption{

    
    if(self.player.rate > 0.0){
        [self Play:nil];
        self.interruptedWhilePlaying = YES;
    }
    
    NSLog(@"Audio Session Interrupt : play stop : %d", self.interruptedWhilePlaying);    

}

- (void)endInterruptionWithFlags:(NSUInteger)flags{

    if(self.interruptedWhilePlaying == YES){
        self.interruptedWhilePlaying = FALSE;
        [self Play:nil];
    }
    
    NSLog(@"Audio Session Interrupt : end : %d", self.interruptedWhilePlaying);
    
}


@end


